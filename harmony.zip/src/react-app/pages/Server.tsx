import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Hash, Volume2, Plus, Settings, Send, Loader2, Users, X, Copy, Check, UserCircle, UserPlus } from "lucide-react";
import type { ServerWithChannels, Channel, MessageWithUser, CreateChannel, MemberWithUser } from "@/shared/types";
import CreateChannelModal from "@/react-app/components/CreateChannelModal";
import MembersList from "@/react-app/components/MembersList";
import WebRTCVoiceChannel from "@/react-app/components/WebRTCVoiceChannel";
import UserProfile from "@/react-app/components/UserProfile";
import FriendsPanel from "@/react-app/components/FriendsPanel";
import { useServerSocket } from "@/react-app/hooks/useSocket";

export default function Server() {
  const { serverId, channelId } = useParams<{ serverId: string; channelId?: string }>();
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  useServerSocket(serverId || 0); // For future real-time sync
  
  const [server, setServer] = useState<ServerWithChannels | null>(null);
  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<MessageWithUser[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [showCreateChannel, setShowCreateChannel] = useState(false);
  const [showServerSettings, setShowServerSettings] = useState(false);
  const [showMembersList, setShowMembersList] = useState(true);
  const [members, setMembers] = useState<MemberWithUser[]>([]);
  const [serverSettings, setServerSettings] = useState({ name: "", inviteCode: "" });
  const [copiedInvite, setCopiedInvite] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [showFriendsPanel, setShowFriendsPanel] = useState(false);

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
      return;
    }
    
    if (serverId && user) {
      fetchServer();
    }
  }, [serverId, user, isPending]);

  // Polling for real-time updates (simplified approach)
  useEffect(() => {
    if (!activeChannel || activeChannel.type !== 'text') return;

    const interval = setInterval(() => {
      // Refetch messages periodically for real-time updates
      fetchMessages(activeChannel.id);
    }, 2000); // Poll every 2 seconds for faster updates

    return () => clearInterval(interval);
  }, [activeChannel]);

  useEffect(() => {
    if (server && channelId) {
      const channel = server.channels.find(c => c.id.toString() === channelId);
      if (channel) {
        setActiveChannel(channel);
        if (channel.type === 'text') {
          fetchMessages(channel.id);
        }
      }
    } else if (server && !channelId) {
      // Auto-select first text channel
      const firstTextChannel = server.channels.find(c => c.type === 'text');
      if (firstTextChannel) {
        navigate(`/servers/${serverId}/channels/${firstTextChannel.id}`, { replace: true });
      }
    }
  }, [server, channelId, serverId]);

  const fetchServer = async () => {
    try {
      const response = await fetch(`/api/servers/${serverId}`);
      if (response.ok) {
        const data = await response.json();
        setServer(data);
        setServerSettings({ name: data.name, inviteCode: data.invite_code || "" });
        fetchMembers();
      } else if (response.status === 403) {
        navigate("/dashboard");
      }
    } catch (error) {
      console.error("Failed to fetch server:", error);
    } finally {
      setLoading(false);
    }
  };

  const createChannel = async (channelData: CreateChannel) => {
    try {
      const response = await fetch(`/api/servers/${serverId}/channels`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(channelData),
      });
      
      if (response.ok) {
        const newChannel = await response.json();
        setServer(prev => prev ? {
          ...prev,
          channels: [...prev.channels, newChannel]
        } : null);
        setShowCreateChannel(false);
        navigate(`/servers/${serverId}/channels/${newChannel.id}`);
      }
    } catch (error) {
      console.error("Failed to create channel:", error);
    }
  };

  const generateInviteCode = async () => {
    try {
      const response = await fetch(`/api/servers/${serverId}/invite-code`, {
        method: "POST",
      });
      
      if (response.ok) {
        const data = await response.json();
        setServerSettings(prev => ({ ...prev, inviteCode: data.invite_code }));
        setServer(prev => prev ? { ...prev, invite_code: data.invite_code } : null);
      }
    } catch (error) {
      console.error("Failed to generate invite code:", error);
    }
  };

  const copyInviteCode = async () => {
    if (serverSettings.inviteCode) {
      await navigator.clipboard.writeText(serverSettings.inviteCode);
      setCopiedInvite(true);
      setTimeout(() => setCopiedInvite(false), 2000);
    }
  };

  const updateServerName = async (newName: string) => {
    try {
      const response = await fetch(`/api/servers/${serverId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newName }),
      });
      
      if (response.ok) {
        setServer(prev => prev ? { ...prev, name: newName } : null);
        setServerSettings(prev => ({ ...prev, name: newName }));
      }
    } catch (error) {
      console.error("Failed to update server name:", error);
    }
  };

  const fetchMembers = async () => {
    try {
      const response = await fetch(`/api/servers/${serverId}/members`);
      if (response.ok) {
        const data = await response.json();
        setMembers(data);
      }
    } catch (error) {
      console.error("Failed to fetch members:", error);
    }
  };

  const fetchMessages = async (channelId: number) => {
    try {
      const response = await fetch(`/api/channels/${channelId}/messages`);
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error("Failed to fetch messages:", error);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeChannel || sending) return;

    setSending(true);
    try {
      const response = await fetch(`/api/channels/${activeChannel.id}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: newMessage.trim() }),
      });
      
      if (response.ok) {
        const message = await response.json();
        setMessages(prev => [...prev, message]);
        setNewMessage("");
        
        // Scroll to bottom after sending message
        setTimeout(() => {
          const messagesContainer = document.querySelector('.messages-container');
          if (messagesContainer) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
          }
        }, 100);
      }
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setSending(false);
    }
  };

  if (isPending || loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  if (!server) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl text-white mb-2">Сервер не найден</h2>
          <button
            onClick={() => navigate("/dashboard")}
            className="text-indigo-400 hover:text-indigo-300"
          >
            Вернуться к панели
          </button>
        </div>
      </div>
    );
  }

  const textChannels = server.channels.filter(c => c.type === 'text');
  const voiceChannels = server.channels.filter(c => c.type === 'voice');

  return (
    <div className="min-h-screen bg-gray-900 flex">
      {/* Server Sidebar - Reduced width */}
      <div className="w-16 bg-gray-800 flex flex-col items-center py-3 space-y-2">
        <button 
          onClick={() => navigate("/dashboard")}
          className="w-12 h-12 bg-indigo-600 hover:bg-indigo-500 rounded-2xl hover:rounded-xl transition-all duration-200 flex items-center justify-center"
        >
          <Hash className="w-6 h-6 text-white" />
        </button>
        <div className="w-8 h-0.5 bg-gray-600 rounded-full"></div>
        <div className="w-12 h-12 bg-indigo-600 rounded-2xl flex items-center justify-center text-white font-semibold">
          {server.name.charAt(0).toUpperCase()}
        </div>
      </div>

      {/* Channel Sidebar */}
      <div className="w-60 bg-gray-800 flex flex-col">
        {/* Server Header */}
        <div className="h-12 border-b border-gray-700 flex items-center justify-between px-4">
          <h2 className="text-white font-semibold truncate">{server.name}</h2>
          <button
            onClick={() => setShowServerSettings(true)}
            className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>

        {/* Channel List */}
        <div className="flex-1 overflow-y-auto p-2">
          {/* Text Channels */}
          {textChannels.length > 0 && (
            <div className="mb-4">
              <div className="flex items-center justify-between px-2 py-1 mb-1">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
                  Текстовые каналы
                </span>
                <button
                  onClick={() => setShowCreateChannel(true)}
                  className="p-0.5 text-gray-400 hover:text-white hover:bg-gray-600 rounded"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              {textChannels.map((channel) => (
                <button
                  key={channel.id}
                  onClick={() => navigate(`/servers/${serverId}/channels/${channel.id}`)}
                  className={`w-full flex items-center space-x-2 px-2 py-1 rounded text-left hover:bg-gray-700 transition-colors duration-150 ${
                    activeChannel?.id === channel.id ? 'bg-gray-700 text-white' : 'text-gray-300'
                  }`}
                >
                  <Hash className="w-4 h-4" />
                  <span className="truncate">{channel.name}</span>
                </button>
              ))}
            </div>
          )}

          {/* Voice Channels */}
          {voiceChannels.length > 0 && (
            <div>
              <div className="flex items-center justify-between px-2 py-1 mb-1">
                <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
                  Голосовые каналы
                </span>
                <button
                  onClick={() => setShowCreateChannel(true)}
                  className="p-0.5 text-gray-400 hover:text-white hover:bg-gray-600 rounded"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              {voiceChannels.map((channel) => (
                <button
                  key={channel.id}
                  onClick={() => navigate(`/servers/${serverId}/channels/${channel.id}`)}
                  className={`w-full flex items-center space-x-2 px-2 py-1 rounded text-left hover:bg-gray-700 transition-colors duration-150 ${
                    activeChannel?.id === channel.id ? 'bg-gray-700 text-white' : 'text-gray-300'
                  }`}
                >
                  <Volume2 className="w-4 h-4" />
                  <span className="truncate">{channel.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* User Panel */}
        <div className="h-14 bg-gray-900 flex items-center justify-between px-2 border-t border-gray-700">
          <button
            onClick={() => setShowUserProfile(true)}
            className="flex items-center space-x-2 flex-1 min-w-0 hover:bg-gray-800 p-1 rounded transition-colors duration-200"
          >
            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
              <span className="text-xs font-semibold text-white">
                {user?.google_user_data?.given_name?.charAt(0) || user?.email?.charAt(0)}
              </span>
            </div>
            <div className="min-w-0 flex-1 text-left">
              <div className="text-sm font-medium text-white truncate">
                {user?.google_user_data?.name || user?.email}
              </div>
              <div className="text-xs text-gray-400">В сети</div>
            </div>
          </button>
          <div className="flex space-x-1">
            <button 
              onClick={() => setShowFriendsPanel(true)}
              className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
              title="Друзья"
            >
              <UserPlus className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setShowUserProfile(true)}
              className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
              title="Настройки профиля"
            >
              <UserCircle className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Chat Area */}
      <div className="flex-1 flex flex-col">
        {activeChannel && activeChannel.type === 'text' ? (
          <>
            {/* Chat Header */}
            <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
              <div className="flex items-center">
                <Hash className="w-5 h-5 text-gray-400 mr-2" />
                <span className="text-white font-medium">{activeChannel.name}</span>
                {activeChannel.description && (
                  <span className="text-gray-400 ml-2 text-sm">| {activeChannel.description}</span>
                )}
              </div>
              <button
                onClick={() => setShowMembersList(!showMembersList)}
                className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
                title={showMembersList ? "Скрыть список участников" : "Показать список участников"}
              >
                <Users className="w-5 h-5" />
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 messages-container">
              {messages.map((message) => (
                <div key={message.id} className="flex space-x-3">
                  <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center flex-shrink-0">
                    {message.user_avatar ? (
                      <img 
                        src={message.user_avatar} 
                        alt={message.user_name}
                        className="w-10 h-10 rounded-full"
                      />
                    ) : (
                      <span className="text-sm font-semibold text-white">
                        {message.user_name.charAt(0).toUpperCase()}
                      </span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline space-x-2 mb-1">
                      <span className="text-white font-medium">{message.user_name}</span>
                      <span className="text-xs text-gray-400">
                        {new Date(message.created_at).toLocaleString('ru-RU')}
                      </span>
                    </div>
                    <p className="text-gray-300 break-words">{message.content}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-gray-700">
              <form onSubmit={sendMessage} className="flex space-x-2">
                <input
                  type="text"
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder={`Сообщение #${activeChannel.name}`}
                  className="flex-1 px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
                  disabled={sending}
                />
                <button
                  type="submit"
                  disabled={!newMessage.trim() || sending}
                  className="px-4 py-3 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg transition-colors duration-200"
                >
                  {sending ? (
                    <Loader2 className="w-5 h-5 animate-spin" />
                  ) : (
                    <Send className="w-5 h-5" />
                  )}
                </button>
              </form>
            </div>
          </>
        ) : activeChannel && activeChannel.type === 'voice' ? (
          <WebRTCVoiceChannel
            channelId={activeChannel.id}
            channelName={activeChannel.name}
            onLeave={() => {
              // Navigate back to first text channel or dashboard
              const firstTextChannel = server?.channels.find(c => c.type === 'text');
              if (firstTextChannel) {
                navigate(`/servers/${serverId}/channels/${firstTextChannel.id}`, { replace: true });
              } else {
                navigate(`/servers/${serverId}`, { replace: true });
              }
            }}
          />
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <Volume2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Выберите канал</h3>
              <p className="text-gray-400">Выберите текстовый или голосовой канал для начала общения</p>
            </div>
          </div>
        )}
      </div>

      {/* Members List */}
      <MembersList members={members} isVisible={showMembersList} />

      {/* Create Channel Modal */}
      {showCreateChannel && (
        <CreateChannelModal
          onClose={() => setShowCreateChannel(false)}
          onCreate={createChannel}
        />
      )}

      {/* Server Settings Modal */}
      {showServerSettings && server && (
        <ServerSettingsModal
          server={server}
          onClose={() => setShowServerSettings(false)}
          onUpdateName={updateServerName}
          onGenerateInvite={generateInviteCode}
          onCopyInvite={copyInviteCode}
          inviteCode={serverSettings.inviteCode}
          copiedInvite={copiedInvite}
        />
      )}

      {/* User Profile Modal */}
      <UserProfile 
        isOpen={showUserProfile}
        onClose={() => setShowUserProfile(false)}
      />

      {/* Friends Panel */}
      <FriendsPanel 
        isOpen={showFriendsPanel}
        onClose={() => setShowFriendsPanel(false)}
      />
    </div>
  );
}

function ServerSettingsModal({ 
  server, 
  onClose, 
  onUpdateName, 
  onGenerateInvite, 
  onCopyInvite,
  inviteCode,
  copiedInvite 
}: { 
  server: ServerWithChannels;
  onClose: () => void;
  onUpdateName: (name: string) => void;
  onGenerateInvite: () => void;
  onCopyInvite: () => void;
  inviteCode: string;
  copiedInvite: boolean;
}) {
  const [name, setName] = useState(server.name);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim() && name.trim() !== server.name) {
      onUpdateName(name.trim());
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white">Настройки сервера</h3>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Название сервера
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
              maxLength={100}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Код приглашения
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={inviteCode}
                readOnly
                className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                placeholder="Не создан"
              />
              {inviteCode ? (
                <button
                  type="button"
                  onClick={onCopyInvite}
                  className="px-3 py-2 bg-gray-600 hover:bg-gray-500 text-white rounded-lg flex items-center space-x-1"
                >
                  {copiedInvite ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onGenerateInvite}
                  className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg"
                >
                  Создать
                </button>
              )}
            </div>
            <p className="text-xs text-gray-400 mt-1">
              Участники смогут присоединиться к серверу по этому коду
            </p>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-300 hover:text-white transition-colors duration-200"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors duration-200"
            >
              Сохранить
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
