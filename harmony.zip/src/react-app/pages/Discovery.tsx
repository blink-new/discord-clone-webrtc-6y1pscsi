import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Search, Users, Globe, Lock, ArrowRight, Loader2 } from "lucide-react";
import type { Server } from "@/shared/types";

export default function Discovery() {
  const { user, isPending } = useAuth();
  const navigate = useNavigate();
  const [publicServers, setPublicServers] = useState<Server[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [joinLoading, setJoinLoading] = useState(false);

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
      return;
    }
    
    if (user) {
      fetchPublicServers();
      
      // Poll for server updates every 10 seconds
      const interval = setInterval(fetchPublicServers, 10000);
      return () => clearInterval(interval);
    }
  }, [user, isPending]);

  const fetchPublicServers = async () => {
    try {
      const response = await fetch("/api/discovery/servers");
      if (response.ok) {
        const data = await response.json();
        setPublicServers(data);
      } else if (response.status === 401) {
        navigate("/");
      } else {
        console.error("Failed to fetch servers:", response.status);
      }
    } catch (error) {
      console.error("Failed to fetch public servers:", error);
    } finally {
      setLoading(false);
    }
  };

  const joinServer = async (serverId: number) => {
    try {
      const response = await fetch(`/api/servers/${serverId}/join`, {
        method: "POST",
      });
      
      if (response.ok) {
        navigate(`/servers/${serverId}`);
      }
    } catch (error) {
      console.error("Failed to join server:", error);
    }
  };

  const joinByCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!joinCode.trim()) return;

    setJoinLoading(true);
    try {
      const response = await fetch("/api/servers/join-by-code", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ invite_code: joinCode.trim().toUpperCase() }),
      });
      
      if (response.ok) {
        const server = await response.json();
        setShowJoinModal(false);
        setJoinCode("");
        navigate(`/servers/${server.id}`);
      } else {
        alert("Код приглашения не найден или недействителен");
      }
    } catch (error) {
      console.error("Failed to join by code:", error);
      alert("Ошибка при присоединении к серверу");
    } finally {
      setJoinLoading(false);
    }
  };

  const filteredServers = publicServers.filter(server =>
    server.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (server.description && server.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  if (isPending || loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => navigate("/dashboard")}
              className="text-gray-400 hover:text-white transition-colors duration-200"
            >
              ← Назад
            </button>
            <div className="flex items-center space-x-2">
              <Globe className="w-6 h-6 text-indigo-400" />
              <h1 className="text-2xl font-bold text-white">Путешествия</h1>
            </div>
          </div>
          <button
            onClick={() => setShowJoinModal(true)}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-colors duration-200"
          >
            Присоединиться по коду
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Поиск серверов..."
              className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
            />
          </div>
        </div>

        {/* Server Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredServers.map((server) => (
            <div
              key={server.id}
              className="bg-gray-800 rounded-xl p-6 border border-gray-700 hover:border-gray-600 transition-all duration-200 group"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  {server.icon_url ? (
                    <img
                      src={server.icon_url}
                      alt={server.name}
                      className="w-12 h-12 rounded-xl"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-indigo-600 rounded-xl flex items-center justify-center">
                      <span className="text-white font-semibold text-lg">
                        {server.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                  <div>
                    <h3 className="text-lg font-semibold text-white group-hover:text-indigo-400 transition-colors duration-200">
                      {server.name}
                    </h3>
                    <div className="flex items-center space-x-1 text-sm text-gray-400">
                      <Users className="w-4 h-4" />
                      <span>{(server as any).member_count || 0} участников</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {!server.is_public && <Lock className="w-4 h-4 text-gray-400" />}
                </div>
              </div>

              {server.description && (
                <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                  {server.description}
                </p>
              )}

              <button
                onClick={() => joinServer(server.id)}
                className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors duration-200 group"
              >
                <span>Присоединиться</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-200" />
              </button>
            </div>
          ))}
        </div>

        {filteredServers.length === 0 && (
          <div className="text-center py-12">
            <Globe className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-400 mb-2">
              {searchQuery ? "Серверы не найдены" : "Нет доступных серверов"}
            </h3>
            <p className="text-gray-500">
              {searchQuery
                ? "Попробуйте изменить поисковый запрос"
                : "Создайте первый публичный сервер"}
            </p>
          </div>
        )}
      </div>

      {/* Join by Code Modal */}
      {showJoinModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
            <h3 className="text-xl font-bold text-white mb-4">Присоединиться к серверу</h3>
            <form onSubmit={joinByCode}>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Код приглашения
                </label>
                <input
                  type="text"
                  value={joinCode}
                  onChange={(e) => setJoinCode(e.target.value.toUpperCase())}
                  className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500 uppercase"
                  placeholder="ABC123"
                  maxLength={8}
                  required
                />
              </div>
              <div className="flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowJoinModal(false);
                    setJoinCode("");
                  }}
                  className="px-4 py-2 text-gray-300 hover:text-white transition-colors duration-200"
                >
                  Отмена
                </button>
                <button
                  type="submit"
                  disabled={joinLoading}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-600 text-white rounded-lg font-medium transition-colors duration-200 flex items-center space-x-2"
                >
                  {joinLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <span>Присоединиться</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
