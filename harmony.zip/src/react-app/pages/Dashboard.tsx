import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useAuth } from "@getmocha/users-service/react";
import { Plus, Hash, LogOut, Loader2, Users, Compass, UserCircle, UserPlus } from "lucide-react";
import type { ServerWithChannels } from "@/shared/types";
import UserProfile from "@/react-app/components/UserProfile";
import FriendsPanel from "@/react-app/components/FriendsPanel";

export default function Dashboard() {
  const { user, isPending, logout } = useAuth();
  const navigate = useNavigate();
  const [servers, setServers] = useState<ServerWithChannels[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateServer, setShowCreateServer] = useState(false);
  const [showUserProfile, setShowUserProfile] = useState(false);
  const [showFriendsPanel, setShowFriendsPanel] = useState(false);

  useEffect(() => {
    if (!isPending && !user) {
      navigate("/");
    }
  }, [user, isPending, navigate]);

  useEffect(() => {
    if (user) {
      fetchServers();
      
      // Poll for server updates every 5 seconds
      const interval = setInterval(fetchServers, 5000);
      return () => clearInterval(interval);
    }
  }, [user]);

  const fetchServers = async () => {
    try {
      const response = await fetch("/api/servers");
      if (response.ok) {
        const data = await response.json();
        setServers(data);
      }
    } catch (error) {
      console.error("Failed to fetch servers:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateServer = async (serverData: any) => {
    try {
      const response = await fetch("/api/servers", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(serverData),
      });
      
      if (response.ok) {
        const newServer = await response.json();
        setServers(prev => [newServer, ...prev]);
        setShowCreateServer(false);
        navigate(`/servers/${newServer.id}`);
      }
    } catch (error) {
      console.error("Failed to create server:", error);
    }
  };

  if (isPending || !user) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 flex">
      {/* Server Sidebar */}
      <div className="w-16 bg-gray-800 flex flex-col items-center py-3 space-y-2">
        {/* Home Button */}
        <button className="w-12 h-12 bg-indigo-600 hover:bg-indigo-500 rounded-2xl hover:rounded-xl transition-all duration-200 flex items-center justify-center">
          <Hash className="w-6 h-6 text-white" />
        </button>
        
        <div className="w-8 h-0.5 bg-gray-600 rounded-full"></div>
        
        {/* Server Icons */}
        {servers.map((server) => (
          <button
            key={server.id}
            onClick={() => navigate(`/servers/${server.id}`)}
            className="w-12 h-12 bg-gray-700 hover:bg-indigo-600 rounded-2xl hover:rounded-xl transition-all duration-200 flex items-center justify-center text-gray-300 hover:text-white font-semibold"
            title={server.name}
          >
            {server.name.charAt(0).toUpperCase()}
          </button>
        ))}
        
        {/* Add Server Button */}
        <button
          onClick={() => setShowCreateServer(true)}
          className="w-12 h-12 bg-gray-700 hover:bg-green-600 rounded-2xl hover:rounded-xl transition-all duration-200 flex items-center justify-center text-green-400 hover:text-white"
        >
          <Plus className="w-6 h-6" />
        </button>
        
        <div className="w-8 h-0.5 bg-gray-600 rounded-full mt-2"></div>
        
        {/* Discovery Button */}
        <button
          onClick={() => navigate("/discovery")}
          className="w-12 h-12 bg-gray-700 hover:bg-indigo-600 rounded-2xl hover:rounded-xl transition-all duration-200 flex items-center justify-center text-gray-300 hover:text-white"
          title="Путешествия"
        >
          <Compass className="w-6 h-6" />
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
          <div className="flex items-center space-x-2">
            <Hash className="w-5 h-5 text-gray-400" />
            <span className="text-white font-medium">Добро пожаловать в Harmony</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={() => setShowFriendsPanel(true)}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
              title="Друзья"
            >
              <UserPlus className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowUserProfile(true)}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
              title="Профиль"
            >
              <UserCircle className="w-4 h-4" />
            </button>
            <button
              onClick={logout}
              className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center max-w-md">
            <div className="w-24 h-24 bg-indigo-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Users className="w-12 h-12 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">
              Добро пожаловать, {user.google_user_data?.given_name || user.google_user_data?.name || user.email}!
            </h2>
            <p className="text-gray-400 mb-8">
              Выберите сервер слева или создайте новый для начала общения с командой.
            </p>
            
            {loading ? (
              <Loader2 className="w-6 h-6 animate-spin text-indigo-500 mx-auto" />
            ) : servers.length === 0 ? (
              <button
                onClick={() => setShowCreateServer(true)}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors duration-200"
              >
                Создать первый сервер
              </button>
            ) : null}
          </div>
        </div>
      </div>

      {/* Create Server Modal */}
      {showCreateServer && (
        <CreateServerModal
          onClose={() => setShowCreateServer(false)}
          onCreate={handleCreateServer}
        />
      )}

      {/* User Profile Modal */}
      <UserProfile 
        isOpen={showUserProfile}
        onClose={() => setShowUserProfile(false)}
      />

      {/* Friends Panel */}
      <FriendsPanel 
        isOpen={showFriendsPanel}
        onClose={() => setShowFriendsPanel(false)}
      />
    </div>
  );
}

function CreateServerModal({ onClose, onCreate }: { onClose: () => void; onCreate: (data: any) => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [isPublic, setIsPublic] = useState(true);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onCreate({
        name: name.trim(),
        description: description.trim() || undefined,
        is_public: isPublic
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <h3 className="text-xl font-bold text-white mb-4">Создать сервер</h3>
        <form onSubmit={handleSubmit}>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Название сервера
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
              placeholder="Мой супер сервер"
              maxLength={100}
              required
            />
          </div>
          <div className="mb-4">
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Описание сервера
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500 resize-none"
              placeholder="Расскажите о вашем сервере (необязательно)"
              rows={3}
              maxLength={500}
            />
          </div>
          <div className="mb-4">
            <div className="flex items-center space-x-3">
              <input
                type="checkbox"
                id="isPublic"
                checked={isPublic}
                onChange={(e) => setIsPublic(e.target.checked)}
                className="w-4 h-4 text-indigo-600 bg-gray-700 border-gray-600 rounded focus:ring-indigo-500"
              />
              <label htmlFor="isPublic" className="text-sm text-gray-300">
                Публичный сервер (будет отображаться в разделе "Путешествия")
              </label>
            </div>
          </div>
          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-300 hover:text-white transition-colors duration-200"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors duration-200"
            >
              Создать
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
