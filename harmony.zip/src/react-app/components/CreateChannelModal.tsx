import { useState } from "react";
import { X, Hash, Volume2 } from "lucide-react";
import type { CreateChannel } from "@/shared/types";

interface CreateChannelModalProps {
  onClose: () => void;
  onCreate: (channel: CreateChannel) => void;
}

export default function CreateChannelModal({ onClose, onCreate }: CreateChannelModalProps) {
  const [name, setName] = useState("");
  const [type, setType] = useState<'text' | 'voice'>('text');
  const [description, setDescription] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      onCreate({
        name: name.trim(),
        type,
        description: description.trim() || undefined,
      });
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-md">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-white">Создать канал</h3>
          <button
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-white hover:bg-gray-700 rounded"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Тип канала
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setType('text')}
                className={`p-3 rounded-lg border transition-colors duration-200 ${
                  type === 'text'
                    ? 'border-indigo-500 bg-indigo-600/20 text-indigo-400'
                    : 'border-gray-600 bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                <Hash className="w-5 h-5 mx-auto mb-1" />
                <div className="text-sm font-medium">Текстовый</div>
              </button>
              <button
                type="button"
                onClick={() => setType('voice')}
                className={`p-3 rounded-lg border transition-colors duration-200 ${
                  type === 'voice'
                    ? 'border-indigo-500 bg-indigo-600/20 text-indigo-400'
                    : 'border-gray-600 bg-gray-700 text-gray-300 hover:bg-gray-600'
                }`}
              >
                <Volume2 className="w-5 h-5 mx-auto mb-1" />
                <div className="text-sm font-medium">Голосовой</div>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Название канала
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
              placeholder={type === 'text' ? 'general' : 'General'}
              maxLength={100}
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Описание (необязательно)
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500 resize-none"
              placeholder="Описание канала..."
              maxLength={1024}
              rows={3}
            />
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-gray-300 hover:text-white transition-colors duration-200"
            >
              Отмена
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors duration-200"
            >
              Создать канал
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
