import { useState, useEffect } from "react";
import { Users, UserPlus, Mail, Check, X, MessageCircle } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";
import DirectMessagesPanel from "./DirectMessagesPanel";

interface Friend {
  id: number;
  sender_id?: string;
  receiver_id?: string;
  friend_email: string;
  friend_data: any;
  custom_nickname?: string;
  custom_avatar_url?: string;
}

interface FriendRequest {
  id: number;
  sender_email: string;
  sender_data: any;
  custom_nickname?: string;
  custom_avatar_url?: string;
}

interface FriendsPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

interface UserProfile {
  friend_code?: string;
}

export default function FriendsPanel({ isOpen, onClose }: FriendsPanelProps) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'friends' | 'requests' | 'add'>('friends');
  const [friends, setFriends] = useState<Friend[]>([]);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [newFriendEmail, setNewFriendEmail] = useState("");
  const [newFriendCode, setNewFriendCode] = useState("");
  const [addMethod, setAddMethod] = useState<'email' | 'code'>('code');
  const [userProfile, setUserProfile] = useState<UserProfile>({});
  const [loading, setLoading] = useState(false);
  const [selectedFriend, setSelectedFriend] = useState<{
    id: string;
    name: string;
    avatar?: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchFriends();
      fetchFriendRequests();
      fetchUserProfile();
    }
  }, [isOpen]);

  const fetchUserProfile = async () => {
    try {
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const data = await response.json();
        setUserProfile(data);
      }
    } catch (error) {
      console.error("Failed to fetch user profile:", error);
    }
  };

  const fetchFriends = async () => {
    try {
      const response = await fetch("/api/friends");
      if (response.ok) {
        const data = await response.json();
        setFriends(data);
      }
    } catch (error) {
      console.error("Failed to fetch friends:", error);
    }
  };

  const fetchFriendRequests = async () => {
    try {
      const response = await fetch("/api/friend-requests");
      if (response.ok) {
        const data = await response.json();
        setFriendRequests(data);
      }
    } catch (error) {
      console.error("Failed to fetch friend requests:", error);
    }
  };

  const sendFriendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const requestData: any = {};
    if (addMethod === 'email') {
      if (!newFriendEmail.trim()) return;
      requestData.receiver_email = newFriendEmail.trim();
    } else {
      if (!newFriendCode.trim()) return;
      requestData.friend_code = newFriendCode.trim().toUpperCase();
    }

    setLoading(true);
    try {
      const response = await fetch("/api/friend-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(requestData),
      });

      if (response.ok) {
        setNewFriendEmail("");
        setNewFriendCode("");
        alert("Заявка в друзья отправлена!");
      } else {
        const error = await response.json();
        alert(error.error || "Ошибка отправки заявки");
      }
    } catch (error) {
      console.error("Failed to send friend request:", error);
      alert("Ошибка отправки заявки");
    } finally {
      setLoading(false);
    }
  };

  const respondToRequest = async (requestId: number, status: 'accepted' | 'declined') => {
    try {
      const response = await fetch(`/api/friend-requests/${requestId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });

      if (response.ok) {
        setFriendRequests(prev => prev.filter(req => req.id !== requestId));
        if (status === 'accepted') {
          fetchFriends(); // Refresh friends list
        }
      }
    } catch (error) {
      console.error("Failed to respond to friend request:", error);
    }
  };

  if (!isOpen) return null;

  if (selectedFriend) {
    return (
      <DirectMessagesPanel
        friendId={selectedFriend.id}
        friendName={selectedFriend.name}
        friendAvatar={selectedFriend.avatar}
        onClose={() => setSelectedFriend(null)}
      />
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gray-900 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Users className="w-6 h-6 text-indigo-400" />
            <h2 className="text-xl font-bold text-white">Друзья</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-gray-400 hover:text-white hover:bg-gray-700 rounded-lg transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="bg-gray-900 px-6 py-2 border-t border-gray-700">
          <div className="flex space-x-4">
            <button
              onClick={() => setActiveTab('friends')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                activeTab === 'friends'
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-300 hover:text-white hover:bg-gray-700'
              }`}
            >
              Друзья ({friends.length})
            </button>
            <button
              onClick={() => setActiveTab('requests')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 relative ${
                activeTab === 'requests'
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-300 hover:text-white hover:bg-gray-700'
              }`}
            >
              Заявки ({friendRequests.length})
              {friendRequests.length > 0 && (
                <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center">
                  <span className="text-xs text-white">{friendRequests.length}</span>
                </div>
              )}
            </button>
            <button
              onClick={() => setActiveTab('add')}
              className={`px-3 py-2 text-sm font-medium rounded-lg transition-colors duration-200 ${
                activeTab === 'add'
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-300 hover:text-white hover:bg-gray-700'
              }`}
            >
              Добавить
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'friends' && (
            <div className="space-y-3">
              {friends.length === 0 ? (
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-400 mb-2">Пока нет друзей</h3>
                  <p className="text-gray-500">Добавьте друзей, чтобы общаться с ними!</p>
                </div>
              ) : (
                friends.map((friend) => {
                  const friendData = JSON.parse(friend.friend_data);
                  const displayName = friend.custom_nickname || friendData.name || friend.friend_email;
                  const avatar = friend.custom_avatar_url || friendData.picture;

                  return (
                    <div key={friend.id} className="flex items-center space-x-3 p-3 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors duration-200">
                      {avatar ? (
                        <img
                          src={avatar}
                          alt={displayName}
                          className="w-12 h-12 rounded-full"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center">
                          <span className="text-white font-semibold">
                            {displayName.charAt(0).toUpperCase()}
                          </span>
                        </div>
                      )}
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-white truncate">{displayName}</h4>
                        <p className="text-sm text-gray-400 truncate">{friend.friend_email}</p>
                      </div>

                      <button
                        onClick={() => {
                          // Determine friend ID based on current user
                          const friendUserId = friend.sender_id === user?.id ? friend.receiver_id : friend.sender_id;
                          if (friendUserId) {
                            setSelectedFriend({
                              id: friendUserId,
                              name: displayName,
                              avatar: friend.custom_avatar_url || friendData.picture
                            });
                          }
                        }}
                        className="p-2 text-gray-400 hover:text-white hover:bg-gray-600 rounded-lg transition-colors duration-200"
                        title="Отправить сообщение"
                      >
                        <MessageCircle className="w-5 h-5" />
                      </button>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {activeTab === 'requests' && (
            <div className="space-y-3">
              {friendRequests.length === 0 ? (
                <div className="text-center py-12">
                  <Mail className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-gray-400 mb-2">Нет новых заявок</h3>
                  <p className="text-gray-500">Здесь будут отображаться заявки в друзья</p>
                </div>
              ) : (
                friendRequests.map((request) => {
                  const senderData = JSON.parse(request.sender_data);
                  const displayName = request.custom_nickname || senderData.name || request.sender_email;
                  const avatar = request.custom_avatar_url || senderData.picture;

                  return (
                    <div key={request.id} className="flex items-center space-x-3 p-3 bg-gray-700 rounded-lg">
                      {avatar ? (
                        <img
                          src={avatar}
                          alt={displayName}
                          className="w-12 h-12 rounded-full"
                        />
                      ) : (
                        <div className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center">
                          <span className="text-white font-semibold">
                            {displayName.charAt(0).toUpperCase()}
                          </span>
                        </div>
                      )}
                      
                      <div className="flex-1 min-w-0">
                        <h4 className="font-semibold text-white truncate">{displayName}</h4>
                        <p className="text-sm text-gray-400 truncate">{request.sender_email}</p>
                        <p className="text-xs text-gray-500">Хочет добавить вас в друзья</p>
                      </div>

                      <div className="flex space-x-2">
                        <button
                          onClick={() => respondToRequest(request.id, 'accepted')}
                          className="p-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors duration-200"
                          title="Принять"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => respondToRequest(request.id, 'declined')}
                          className="p-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors duration-200"
                          title="Отклонить"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          )}

          {activeTab === 'add' && (
            <div>
              {/* Your Friend Code */}
              {userProfile.friend_code && (
                <div className="mb-6 p-4 bg-indigo-600/20 border border-indigo-500/30 rounded-lg">
                  <h4 className="font-semibold text-white mb-2">🎯 Ваш код друга</h4>
                  <div className="flex items-center space-x-2">
                    <code className="bg-gray-800 px-3 py-2 rounded text-white font-mono text-lg">
                      {userProfile.friend_code}
                    </code>
                    <button
                      onClick={() => navigator.clipboard.writeText(userProfile.friend_code!)}
                      className="px-3 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded transition-colors duration-200"
                      title="Скопировать"
                    >
                      📋
                    </button>
                  </div>
                  <p className="text-sm text-gray-300 mt-2">
                    Поделитесь этим кодом с друзьями, чтобы они могли добавить вас
                  </p>
                </div>
              )}

              {/* Add Method Toggle */}
              <div className="mb-4">
                <div className="flex bg-gray-700 rounded-lg p-1">
                  <button
                    onClick={() => setAddMethod('code')}
                    className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                      addMethod === 'code'
                        ? 'bg-indigo-600 text-white'
                        : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    По коду
                  </button>
                  <button
                    onClick={() => setAddMethod('email')}
                    className={`flex-1 px-3 py-2 text-sm font-medium rounded-md transition-colors duration-200 ${
                      addMethod === 'email'
                        ? 'bg-indigo-600 text-white'
                        : 'text-gray-300 hover:text-white'
                    }`}
                  >
                    По email
                  </button>
                </div>
              </div>

              <form onSubmit={sendFriendRequest} className="space-y-4">
                {addMethod === 'code' ? (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Код друга
                    </label>
                    <input
                      type="text"
                      value={newFriendCode}
                      onChange={(e) => setNewFriendCode(e.target.value.toUpperCase())}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500 uppercase font-mono text-center text-lg"
                      placeholder="ABC123"
                      maxLength={6}
                      required
                    />
                  </div>
                ) : (
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Email пользователя
                    </label>
                    <input
                      type="email"
                      value={newFriendEmail}
                      onChange={(e) => setNewFriendEmail(e.target.value)}
                      className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
                      placeholder="user@example.com"
                      required
                    />
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading || (addMethod === 'code' ? !newFriendCode.trim() : !newFriendEmail.trim())}
                  className="w-full px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-600 text-white rounded-lg font-medium transition-colors duration-200 flex items-center justify-center space-x-2"
                >
                  {loading ? (
                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  ) : (
                    <>
                      <UserPlus className="w-5 h-5" />
                      <span>Отправить заявку</span>
                    </>
                  )}
                </button>
              </form>

              <div className="mt-8 p-4 bg-gray-700 rounded-lg">
                <h4 className="font-semibold text-white mb-2">💡 Как добавить друга</h4>
                <ul className="text-sm text-gray-300 space-y-1">
                  <li>• <strong>По коду:</strong> Попросите друга поделиться своим кодом</li>
                  <li>• <strong>По email:</strong> Введите email пользователя</li>
                  <li>• Друг получит уведомление о вашей заявке</li>
                  <li>• После принятия заявки вы сможете общаться напрямую</li>
                </ul>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
