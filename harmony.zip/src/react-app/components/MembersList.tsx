import { useState } from "react";
import { Crown, Shield, User, ChevronRight, ChevronDown } from "lucide-react";
import type { MemberWithUser } from "@/shared/types";

interface MembersListProps {
  members: MemberWithUser[];
  isVisible: boolean;
}

export default function MembersList({ members, isVisible }: MembersListProps) {
  const [collapsedRoles, setCollapsedRoles] = useState<Set<string>>(new Set());

  if (!isVisible) return null;

  const toggleRole = (role: string) => {
    const newCollapsed = new Set(collapsedRoles);
    if (newCollapsed.has(role)) {
      newCollapsed.delete(role);
    } else {
      newCollapsed.add(role);
    }
    setCollapsedRoles(newCollapsed);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="w-4 h-4 text-yellow-400" />;
      case 'admin':
        return <Shield className="w-4 h-4 text-red-400" />;
      default:
        return <User className="w-4 h-4 text-gray-400" />;
    }
  };

  const getRoleName = (role: string) => {
    switch (role) {
      case 'owner':
        return 'Владелец';
      case 'admin':
        return 'Администраторы';
      default:
        return 'Участники';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'idle':
        return 'bg-yellow-500';
      case 'dnd':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  // Group members by role
  const groupedMembers = members.reduce((acc, member) => {
    if (!acc[member.role]) {
      acc[member.role] = [];
    }
    acc[member.role].push(member);
    return acc;
  }, {} as Record<string, MemberWithUser[]>);

  // Sort roles: owner, admin, member
  const roleOrder = ['owner', 'admin', 'member'];
  const sortedRoles = roleOrder.filter(role => groupedMembers[role]?.length > 0);

  return (
    <div className="w-60 bg-gray-800 border-l border-gray-700 flex flex-col">
      <div className="p-4 border-b border-gray-700">
        <h3 className="text-sm font-semibold text-gray-300 uppercase tracking-wide">
          Участники — {members.length}
        </h3>
      </div>

      <div className="flex-1 overflow-y-auto p-2">
        {sortedRoles.map((role) => {
          const roleMembers = groupedMembers[role];
          const isCollapsed = collapsedRoles.has(role);

          return (
            <div key={role} className="mb-4">
              <button
                onClick={() => toggleRole(role)}
                className="w-full flex items-center justify-between px-2 py-1 text-xs font-semibold text-gray-400 uppercase tracking-wide hover:text-gray-300 transition-colors duration-200"
              >
                <div className="flex items-center space-x-2">
                  {getRoleIcon(role)}
                  <span>{getRoleName(role)} — {roleMembers.length}</span>
                </div>
                {isCollapsed ? (
                  <ChevronRight className="w-3 h-3" />
                ) : (
                  <ChevronDown className="w-3 h-3" />
                )}
              </button>

              {!isCollapsed && (
                <div className="mt-1 space-y-1">
                  {roleMembers
                    .sort((a, b) => a.user_name.localeCompare(b.user_name))
                    .map((member) => (
                      <div
                        key={member.id}
                        className="flex items-center space-x-3 px-2 py-1 rounded hover:bg-gray-700 transition-colors duration-200 cursor-pointer"
                      >
                        <div className="relative">
                          {member.user_avatar ? (
                            <img
                              src={member.user_avatar}
                              alt={member.user_name}
                              className="w-8 h-8 rounded-full"
                            />
                          ) : (
                            <div className="w-8 h-8 bg-indigo-600 rounded-full flex items-center justify-center">
                              <span className="text-xs font-semibold text-white">
                                {member.user_name.charAt(0).toUpperCase()}
                              </span>
                            </div>
                          )}
                          <div
                            className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-gray-800 ${getStatusColor(member.status)}`}
                          />
                        </div>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-1">
                            <span className="text-sm text-gray-300 truncate">
                              {member.user_name}
                            </span>
                            {role !== 'member' && (
                              <div className="flex-shrink-0">
                                {getRoleIcon(role)}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
