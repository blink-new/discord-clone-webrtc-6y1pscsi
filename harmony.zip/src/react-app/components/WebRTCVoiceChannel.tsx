import { useState, useEffect, useRef, useCallback } from "react";
import { Mic, MicOff, Volume2, VolumeX, Phone, PhoneOff, Users } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";

interface VoiceChannelProps {
  channelId: number;
  channelName: string;
  onLeave: () => void;
}

interface VoiceUser {
  id: string;
  name: string;
  avatar: string | null;
  isMuted: boolean;
  isSpeaking: boolean;
}

interface PeerConnection {
  connection: RTCPeerConnection;
  remoteAudio: HTMLAudioElement;
}

export default function WebRTCVoiceChannel({ channelId, channelName, onLeave }: VoiceChannelProps) {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [voiceUsers, setVoiceUsers] = useState<VoiceUser[]>([]);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [connecting, setConnecting] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('');
  
  // WebRTC state
  const [peerConnections, setPeerConnections] = useState<Map<string, PeerConnection>>(new Map());
  const localStreamRef = useRef<MediaStream | null>(null);
  const websocketRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  
  // Audio analysis for voice activity detection
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [dataArray, setDataArray] = useState<Uint8Array | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const animationFrameRef = useRef<number | null>(null);
  const participantsPollingRef = useRef<NodeJS.Timeout | null>(null);

  // WebRTC configuration with multiple STUN servers
  const rtcConfiguration = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
      { urls: 'stun:stun.ekiga.net' },
    ]
  };

  useEffect(() => {
    return () => {
      cleanup();
    };
  }, []);

  const cleanup = useCallback(() => {
    setConnecting(false);
    setConnectionStatus('');
    
    if (localStream) {
      localStream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      setLocalStream(null);
      localStreamRef.current = null;
    }
    
    if (audioContext) {
      audioContext.close().catch(console.error);
      setAudioContext(null);
      setAnalyser(null);
      setDataArray(null);
    }
    
    if (animationFrameRef.current !== null) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    
    if (participantsPollingRef.current) {
      clearInterval(participantsPollingRef.current);
      participantsPollingRef.current = null;
    }
    
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
      reconnectTimeoutRef.current = null;
    }
    
    if (websocketRef.current) {
      websocketRef.current.close();
      websocketRef.current = null;
    }
    
    // Close all peer connections
    peerConnections.forEach((peer) => {
      peer.connection.close();
      peer.remoteAudio.remove();
    });
    setPeerConnections(new Map());
    
    setVoiceUsers([]);
    setIsSpeaking(false);
    
    if (isConnected) {
      leaveVoiceChannel();
    }
    setIsConnected(false);
  }, [localStream, audioContext, peerConnections, isConnected]);

  // Voice activity detection
  const setupAudioAnalysis = useCallback((stream: MediaStream) => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      const analyserNode = audioCtx.createAnalyser();
      const source = audioCtx.createMediaStreamSource(stream);
      
      analyserNode.fftSize = 256;
      const bufferLength = analyserNode.frequencyBinCount;
      const dataArr = new Uint8Array(bufferLength);
      
      source.connect(analyserNode);
      
      setAudioContext(audioCtx);
      setAnalyser(analyserNode);
      setDataArray(dataArr);
      
      return { audioCtx, analyserNode, dataArr };
    } catch (error) {
      console.error("Failed to setup audio analysis:", error);
      return null;
    }
  }, []);

  const detectVoiceActivity = useCallback(() => {
    if (!analyser || !dataArray || isMuted) {
      setIsSpeaking(false);
      if (isConnected) {
        animationFrameRef.current = requestAnimationFrame(detectVoiceActivity);
      }
      return;
    }

    analyser.getByteFrequencyData(dataArray);
    
    // Calculate average volume
    const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
    const speaking = average > 25; // Lower threshold for better detection
    
    if (speaking !== isSpeaking) {
      setIsSpeaking(speaking);
      
      // Notify other peers about speaking status
      if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
        websocketRef.current.send(JSON.stringify({
          type: 'speaking',
          channelId,
          userId: user?.id,
          speaking
        }));
      }
    }

    if (isConnected) {
      animationFrameRef.current = requestAnimationFrame(detectVoiceActivity);
    }
  }, [analyser, dataArray, isMuted, isSpeaking, user, channelId, isConnected]);

  useEffect(() => {
    if (isConnected && analyser && dataArray) {
      animationFrameRef.current = requestAnimationFrame(detectVoiceActivity);
    }
    return () => {
      if (animationFrameRef.current !== null) {
        cancelAnimationFrame(animationFrameRef.current);
        animationFrameRef.current = null;
      }
    };
  }, [isConnected, analyser, dataArray, detectVoiceActivity]);

  const getUserMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: 44100,
        }, 
        video: false 
      });
      setLocalStream(stream);
      localStreamRef.current = stream;
      
      // Setup audio analysis for voice activity detection
      setupAudioAnalysis(stream);
      
      return stream;
    } catch (error) {
      console.error("Failed to get user media:", error);
      setConnectionStatus('Ошибка доступа к микрофону');
      return null;
    }
  };

  const createPeerConnection = useCallback(async (remoteUserId: string, isInitiator: boolean = false) => {
    console.log(`Creating peer connection with ${remoteUserId}, initiator: ${isInitiator}`);
    
    const peerConnection = new RTCPeerConnection(rtcConfiguration);
    
    // Create remote audio element
    const remoteAudio = document.createElement('audio');
    remoteAudio.autoplay = true;
    remoteAudio.controls = false;
    remoteAudio.volume = isDeafened ? 0 : 1;
    document.body.appendChild(remoteAudio);
    
    // Handle remote stream
    peerConnection.ontrack = (event) => {
      console.log('Received remote track from:', remoteUserId);
      remoteAudio.srcObject = event.streams[0];
    };
    
    // Handle ICE candidates
    peerConnection.onicecandidate = (event) => {
      if (event.candidate && websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
        websocketRef.current.send(JSON.stringify({
          type: 'ice-candidate',
          candidate: event.candidate,
          targetUserId: remoteUserId,
          channelId
        }));
      }
    };

    // Handle connection state changes
    peerConnection.onconnectionstatechange = () => {
      console.log(`Peer connection with ${remoteUserId} state:`, peerConnection.connectionState);
      
      if (peerConnection.connectionState === 'connected') {
        console.log(`Successfully connected to ${remoteUserId}`);
      } else if (peerConnection.connectionState === 'failed') {
        console.log(`Connection failed with ${remoteUserId}, attempting restart`);
        peerConnection.restartIce();
      } else if (peerConnection.connectionState === 'disconnected') {
        console.log(`Disconnected from ${remoteUserId}`);
      }
    };

    peerConnection.oniceconnectionstatechange = () => {
      console.log(`ICE connection with ${remoteUserId}:`, peerConnection.iceConnectionState);
    };
    
    // Add local stream tracks
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStreamRef.current!);
      });
    }
    
    const peerData: PeerConnection = {
      connection: peerConnection,
      remoteAudio
    };
    
    setPeerConnections(prev => {
      const newConnections = new Map(prev);
      newConnections.set(remoteUserId, peerData);
      return newConnections;
    });

    // If we're the initiator, create and send offer
    if (isInitiator) {
      try {
        const offer = await peerConnection.createOffer({
          offerToReceiveAudio: true,
          offerToReceiveVideo: false
        });
        await peerConnection.setLocalDescription(offer);
        
        if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
          websocketRef.current.send(JSON.stringify({
            type: 'offer',
            offer: offer,
            targetUserId: remoteUserId,
            channelId
          }));
        }
      } catch (error) {
        console.error('Failed to create offer:', error);
      }
    }
    
    return peerConnection;
  }, [channelId, isDeafened]);

  const handleWebSocketMessage = useCallback(async (event: MessageEvent) => {
    try {
      const data = JSON.parse(event.data);
      
      switch (data.type) {
        case 'joined':
          console.log('Successfully joined channel');
          setConnectionStatus('Подключено');
          setIsConnected(true);
          fetchVoiceParticipants();
          break;

        case 'participants-list':
          console.log('Received participants list:', data.participants);
          // Create peer connections with existing participants
          for (const participantId of data.participants) {
            if (participantId !== user?.id && !peerConnections.has(participantId)) {
              await createPeerConnection(participantId, true);
            }
          }
          break;

        case 'user-joined':
          console.log('User joined:', data.userId);
          if (data.userId !== user?.id && !peerConnections.has(data.userId)) {
            // New user joins, they should initiate connection to existing users
            await createPeerConnection(data.userId, false);
          }
          fetchVoiceParticipants();
          break;

        case 'user-left':
          console.log('User left:', data.userId);
          const peerData = peerConnections.get(data.userId);
          if (peerData) {
            peerData.connection.close();
            peerData.remoteAudio.remove();
            setPeerConnections(prev => {
              const newConnections = new Map(prev);
              newConnections.delete(data.userId);
              return newConnections;
            });
          }
          fetchVoiceParticipants();
          break;

        case 'offer':
          console.log('Received offer from:', data.fromUserId);
          let offerPeer = peerConnections.get(data.fromUserId);
          if (!offerPeer) {
            // Create peer connection if doesn't exist
            await createPeerConnection(data.fromUserId, false);
            offerPeer = peerConnections.get(data.fromUserId);
          }
          
          if (offerPeer) {
            try {
              await offerPeer.connection.setRemoteDescription(new RTCSessionDescription(data.offer));
              const answer = await offerPeer.connection.createAnswer();
              await offerPeer.connection.setLocalDescription(answer);
              
              if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
                websocketRef.current.send(JSON.stringify({
                  type: 'answer',
                  answer: answer,
                  targetUserId: data.fromUserId,
                  channelId
                }));
              }
            } catch (error) {
              console.error('Failed to handle offer:', error);
            }
          }
          break;

        case 'answer':
          console.log('Received answer from:', data.fromUserId);
          const answerPeer = peerConnections.get(data.fromUserId);
          if (answerPeer) {
            try {
              await answerPeer.connection.setRemoteDescription(new RTCSessionDescription(data.answer));
            } catch (error) {
              console.error('Failed to handle answer:', error);
            }
          }
          break;

        case 'ice-candidate':
          console.log('Received ICE candidate from:', data.fromUserId);
          const icePeer = peerConnections.get(data.fromUserId);
          if (icePeer) {
            try {
              await icePeer.connection.addIceCandidate(new RTCIceCandidate(data.candidate));
            } catch (error) {
              console.error('Failed to add ICE candidate:', error);
            }
          }
          break;

        case 'speaking':
          setVoiceUsers(prev => prev.map(user => 
            user.id === data.userId 
              ? { ...user, isSpeaking: data.speaking }
              : user
          ));
          break;

        case 'mute-status':
          setVoiceUsers(prev => prev.map(user => 
            user.id === data.userId 
              ? { ...user, isMuted: data.muted }
              : user
          ));
          break;

        case 'error':
          console.error('WebSocket error:', data.message);
          setConnectionStatus(`Ошибка: ${data.message}`);
          break;
      }
    } catch (error) {
      console.error('WebSocket message error:', error);
    }
  }, [peerConnections, createPeerConnection, user, channelId]);

  const initializeWebSocket = useCallback(() => {
    if (!user) return null;

    setConnectionStatus('Подключение к серверу...');
    
    // Create WebSocket connection
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/voice/ws`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('WebSocket connected');
      setConnectionStatus('Вход в канал...');
      websocketRef.current = ws;
      
      // Join the voice channel
      ws.send(JSON.stringify({
        type: 'join-channel',
        userId: user.id,
        channelId: channelId.toString()
      }));
    };

    ws.onmessage = handleWebSocketMessage;

    ws.onclose = (event) => {
      console.log('WebSocket disconnected:', event.code, event.reason);
      websocketRef.current = null;
      
      if (isConnected) {
        setConnectionStatus('Соединение потеряно');
        // Auto-reconnect after 3 seconds if we were connected
        reconnectTimeoutRef.current = setTimeout(() => {
          if (isConnected) {
            console.log('Attempting to reconnect...');
            initializeWebSocket();
          }
        }, 3000);
      }
    };

    ws.onerror = (error) => {
      console.error('WebSocket error:', error);
      setConnectionStatus('Ошибка соединения');
    };

    return ws;
  }, [user, channelId, handleWebSocketMessage, isConnected]);

  const connectToVoice = async () => {
    if (connecting || isConnected) return;
    
    setConnecting(true);
    setConnectionStatus('Получение доступа к микрофону...');
    
    try {
      const stream = await getUserMedia();
      if (!stream) {
        throw new Error("Не удалось получить доступ к микрофону");
      }

      // Initialize WebSocket connection
      const ws = initializeWebSocket();
      
      if (ws) {
        // Join voice channel on server
        try {
          const response = await fetch(`/api/channels/${channelId}/voice/join`, {
            method: "POST",
          });
          
          if (!response.ok) {
            throw new Error("Failed to join voice channel on server");
          }
          
          console.log("Joined voice channel on server:", channelId);
          
          // Start polling for participants updates (as backup)
          startParticipantsPolling();
          
        } catch (error) {
          console.error("Failed to join voice channel on server:", error);
          setConnectionStatus('Ошибка подключения к серверу');
          throw error;
        }
      } else {
        throw new Error("Failed to initialize WebSocket");
      }
    } catch (error) {
      console.error("Failed to connect to voice:", error);
      setConnectionStatus('Ошибка подключения');
      cleanup();
    } finally {
      setConnecting(false);
    }
  };

  const leaveVoiceChannel = async () => {
    try {
      await fetch(`/api/channels/${channelId}/voice/leave`, {
        method: "POST",
      });
    } catch (error) {
      console.error("Failed to leave voice channel:", error);
    }
  };

  const disconnectFromVoice = async () => {
    cleanup();
    onLeave();
  };

  const toggleMute = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
        
        // Notify server about mute status
        if (websocketRef.current && websocketRef.current.readyState === WebSocket.OPEN) {
          websocketRef.current.send(JSON.stringify({
            type: 'mute-status',
            channelId,
            userId: user?.id,
            muted: !audioTrack.enabled
          }));
        }
      }
    }
  };

  const toggleDeafen = () => {
    setIsDeafened(prev => {
      const newDeafened = !prev;
      
      // If deafening, also mute
      if (newDeafened && !isMuted) {
        toggleMute();
      }
      
      // Mute/unmute all remote audio elements
      peerConnections.forEach((peer) => {
        peer.remoteAudio.volume = newDeafened ? 0 : 1;
      });
      
      return newDeafened;
    });
  };

  const fetchVoiceParticipants = async () => {
    try {
      const response = await fetch(`/api/channels/${channelId}/voice/participants`);
      if (response.ok) {
        const participants = await response.json();
        const users = participants.map((p: any) => ({
          id: p.user_id,
          name: p.user_name || 'Unknown User',
          avatar: p.user_avatar,
          isMuted: p.is_muted || false,
          isSpeaking: false,
        }));
        
        setVoiceUsers(users);
      }
    } catch (error) {
      console.error("Failed to fetch voice participants:", error);
    }
  };

  const startParticipantsPolling = () => {
    if (participantsPollingRef.current) {
      clearInterval(participantsPollingRef.current);
    }
    
    participantsPollingRef.current = setInterval(() => {
      fetchVoiceParticipants();
    }, 10000); // Poll every 10 seconds as backup
  };

  if (!isConnected) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Volume2 className="w-12 h-12 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">#{channelName}</h3>
          <p className="text-gray-400 mb-8">
            Готовы присоединиться к голосовому каналу? Просто нажмите кнопку ниже.
          </p>
          
          {connectionStatus && (
            <p className="text-sm text-blue-400 mb-4">{connectionStatus}</p>
          )}
          
          <button
            onClick={connectToVoice}
            disabled={connecting}
            className="px-8 py-4 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white rounded-lg font-medium transition-colors duration-200 flex items-center space-x-2 mx-auto"
          >
            {connecting ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Подключение...</span>
              </>
            ) : (
              <>
                <Phone className="w-5 h-5" />
                <span>Подключиться</span>
              </>
            )}
          </button>
          
          <div className="mt-8 text-sm text-gray-500">
            <p>💡 Убедитесь, что браузер имеет доступ к микрофону</p>
            <p className="mt-2">🎧 Используйте наушники для лучшего качества звука</p>
            <p className="mt-2">🌐 P2P соединения для низкой задержки</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Voice Header */}
      <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <Volume2 className="w-5 h-5 text-green-400" />
          <span className="text-white font-medium">#{channelName}</span>
          <div className="flex items-center space-x-1 text-sm text-green-400">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span>Подключен</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm flex items-center space-x-1">
            <Users className="w-4 h-4" />
            <span>{voiceUsers.length}</span>
          </span>
        </div>
      </div>

      {/* Voice Users */}
      <div className="flex-1 p-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {voiceUsers.map((voiceUser) => {
            const isCurrentUser = voiceUser.id === user?.id;
            const userIsSpeaking = isCurrentUser ? isSpeaking : voiceUser.isSpeaking;
            const hasConnection = isCurrentUser || peerConnections.has(voiceUser.id);
            
            return (
              <div
                key={voiceUser.id}
                className={`relative bg-gray-800 rounded-xl p-4 border transition-all duration-200 ${
                  userIsSpeaking 
                    ? 'border-green-400 shadow-lg shadow-green-400/20 ring-2 ring-green-400/30' 
                    : 'border-gray-700'
                }`}
              >
                <div className="text-center">
                  <div className="relative mb-3">
                    {voiceUser.avatar ? (
                      <img
                        src={voiceUser.avatar}
                        alt={voiceUser.name}
                        className={`w-16 h-16 rounded-full mx-auto transition-all duration-200 ${
                          userIsSpeaking ? 'ring-2 ring-green-400' : ''
                        }`}
                      />
                    ) : (
                      <div className={`w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mx-auto transition-all duration-200 ${
                        userIsSpeaking ? 'ring-2 ring-green-400' : ''
                      }`}>
                        <span className="text-lg font-semibold text-white">
                          {voiceUser.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                    )}
                    
                    {/* Muted Indicator */}
                    {voiceUser.isMuted && (
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center border-2 border-gray-800">
                        <MicOff className="w-3 h-3 text-white" />
                      </div>
                    )}
                    
                    {/* Connection Indicator */}
                    {!isCurrentUser && (
                      <div className={`absolute -top-1 -left-1 w-6 h-6 rounded-full flex items-center justify-center border-2 border-gray-800 ${
                        hasConnection ? 'bg-green-600' : 'bg-orange-600'
                      }`}>
                        <div className={`w-2 h-2 rounded-full ${
                          hasConnection ? 'bg-white' : 'bg-white animate-pulse'
                        }`} />
                      </div>
                    )}
                    
                    {/* Speaking Animation */}
                    {userIsSpeaking && (
                      <div className="absolute inset-0 rounded-full bg-green-400/10 animate-pulse" />
                    )}
                  </div>
                  
                  <p className="text-white font-medium text-sm truncate">
                    {voiceUser.name}
                    {isCurrentUser && " (Вы)"}
                  </p>
                  
                  {/* Connection Status */}
                  {!isCurrentUser && (
                    <p className={`text-xs mt-1 ${hasConnection ? 'text-green-400' : 'text-orange-400'}`}>
                      {hasConnection ? 'Соединен' : 'Подключение...'}
                    </p>
                  )}
                  
                  {/* Voice Activity Indicator */}
                  {userIsSpeaking && (
                    <div className="mt-1 flex justify-center">
                      <div className="flex space-x-1">
                        <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse"></div>
                        <div className="w-1 h-4 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
                        <div className="w-1 h-2 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                        <div className="w-1 h-4 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></div>
                        <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
        
        {voiceUsers.length === 1 && (
          <div className="text-center mt-8">
            <p className="text-gray-400">
              🎤 Вы одни в канале. Пригласите друзей присоединиться!
            </p>
          </div>
        )}

        {/* Connection Info */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            🔗 P2P соединений: {peerConnections.size} из {Math.max(0, voiceUsers.length - 1)}
          </p>
          {connectionStatus && (
            <p className="text-xs text-blue-400 mt-1">Статус: {connectionStatus}</p>
          )}
        </div>
      </div>

      {/* Voice Controls */}
      <div className="h-20 bg-gray-900 border-t border-gray-700 flex items-center justify-center space-x-4 px-6">
        {/* Microphone Control */}
        <button
          onClick={toggleMute}
          className={`p-3 rounded-full transition-all duration-200 relative ${
            isMuted
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white'
          } ${isSpeaking && !isMuted ? 'ring-2 ring-green-400/50' : ''}`}
          title={isMuted ? 'Включить микрофон' : 'Выключить микрофон'}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          {isSpeaking && !isMuted && (
            <div className="absolute inset-0 rounded-full bg-green-400/20 animate-ping"></div>
          )}
        </button>

        {/* Audio Control */}
        <button
          onClick={toggleDeafen}
          className={`p-3 rounded-full transition-colors duration-200 ${
            isDeafened
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white'
          }`}
          title={isDeafened ? 'Включить звук' : 'Выключить звук'}
        >
          {isDeafened ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>

        <div className="w-px h-8 bg-gray-600" />

        {/* Connection Status */}
        <div className="flex items-center space-x-2 text-sm">
          <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
          <span className="text-green-400">Онлайн</span>
        </div>

        <div className="w-px h-8 bg-gray-600" />

        {/* Disconnect */}
        <button
          onClick={disconnectFromVoice}
          className="p-3 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors duration-200"
          title="Отключиться от голосового канала"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
