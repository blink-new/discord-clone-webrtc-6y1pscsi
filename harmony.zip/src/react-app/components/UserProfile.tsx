import { useState, useEffect } from "react";
import { useAuth } from "@getmocha/users-service/react";
import { X, Upload, Save, User, Palette, Image } from "lucide-react";

interface UserProfileProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function UserProfile({ isOpen, onClose }: UserProfileProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [profile, setProfile] = useState({
    custom_nickname: "",
    custom_avatar_url: "",
    profile_banner_url: "",
    profile_color: "#5865F2",
    friend_code: "",
  });

  useEffect(() => {
    if (isOpen && user) {
      fetchProfile();
    }
  }, [isOpen, user]);

  const fetchProfile = async () => {
    try {
      const response = await fetch("/api/users/me");
      if (response.ok) {
        const data = await response.json();
        setProfile({
          custom_nickname: data.custom_nickname || "",
          custom_avatar_url: data.custom_avatar_url || "",
          profile_banner_url: data.profile_banner_url || "",
          profile_color: data.profile_color || "#5865F2",
          friend_code: data.friend_code || "",
        });
      }
    } catch (error) {
      console.error("Failed to fetch profile:", error);
    }
  };

  const updateProfile = async () => {
    setLoading(true);
    try {
      const response = await fetch("/api/users/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profile),
      });

      if (response.ok) {
        alert("Профиль обновлен!");
        onClose();
      } else {
        alert("Ошибка обновления профиля");
      }
    } catch (error) {
      console.error("Failed to update profile:", error);
      alert("Ошибка обновления профиля");
    } finally {
      setLoading(false);
    }
  };

  const uploadFile = async (file: File, type: 'avatar' | 'banner') => {
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        body: formData,
      });

      if (response.ok) {
        const data = await response.json();
        setProfile(prev => ({
          ...prev,
          [type === 'avatar' ? 'custom_avatar_url' : 'profile_banner_url']: data.url,
        }));
      } else {
        alert("Ошибка загрузки файла");
      }
    } catch (error) {
      console.error("Upload failed:", error);
      alert("Ошибка загрузки файла");
    }
  };

  if (!isOpen || !user) return null;

  const displayName = profile.custom_nickname || user?.google_user_data?.name || user?.email || "Unknown User";
  const currentAvatar = profile.custom_avatar_url || user?.google_user_data?.picture;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg w-full max-w-lg max-h-[90vh] overflow-y-auto">
        {/* Header with banner */}
        <div 
          className="h-32 relative rounded-t-lg"
          style={{ backgroundColor: profile.profile_color }}
        >
          {profile.profile_banner_url && (
            <img
              src={profile.profile_banner_url}
              alt="Profile banner"
              className="w-full h-full object-cover rounded-t-lg"
            />
          )}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 bg-black/50 hover:bg-black/70 text-white rounded-full transition-colors duration-200"
          >
            <X className="w-5 h-5" />
          </button>
          
          {/* Banner upload button */}
          <label className="absolute top-4 left-4 p-2 bg-black/50 hover:bg-black/70 text-white rounded-full cursor-pointer transition-colors duration-200">
            <Image className="w-5 h-5" />
            <input
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => e.target.files?.[0] && uploadFile(e.target.files[0], 'banner')}
            />
          </label>
        </div>

        {/* Profile content */}
        <div className="p-6 pt-0">
          {/* Avatar */}
          <div className="relative -mt-16 mb-4">
            <div className="relative inline-block">
              {currentAvatar ? (
                <img
                  src={currentAvatar}
                  alt={displayName}
                  className="w-24 h-24 rounded-full border-4 border-gray-800 bg-gray-700"
                />
              ) : (
                <div className="w-24 h-24 rounded-full border-4 border-gray-800 bg-indigo-600 flex items-center justify-center">
                  <span className="text-2xl font-semibold text-white">
                    {displayName.charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
              
              {/* Avatar upload button */}
              <label className="absolute bottom-0 right-0 p-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full cursor-pointer transition-colors duration-200">
                <Upload className="w-4 h-4" />
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => e.target.files?.[0] && uploadFile(e.target.files[0], 'avatar')}
                />
              </label>
            </div>
          </div>

          <h2 className="text-2xl font-bold text-white mb-6">{displayName}</h2>

          {/* Form */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <User className="w-4 h-4 inline mr-2" />
                Отображаемое имя
              </label>
              <input
                type="text"
                value={profile.custom_nickname}
                onChange={(e) => setProfile(prev => ({ ...prev, custom_nickname: e.target.value }))}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
                placeholder={user?.google_user_data?.name || user?.email || "Введите имя"}
                maxLength={50}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                <Palette className="w-4 h-4 inline mr-2" />
                Цвет профиля
              </label>
              <div className="flex space-x-2">
                <input
                  type="color"
                  value={profile.profile_color}
                  onChange={(e) => setProfile(prev => ({ ...prev, profile_color: e.target.value }))}
                  className="w-12 h-10 rounded-lg border border-gray-600 bg-gray-700"
                />
                <input
                  type="text"
                  value={profile.profile_color}
                  onChange={(e) => setProfile(prev => ({ ...prev, profile_color: e.target.value }))}
                  className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
                  placeholder="#5865F2"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                URL аватара
              </label>
              <input
                type="url"
                value={profile.custom_avatar_url}
                onChange={(e) => setProfile(prev => ({ ...prev, custom_avatar_url: e.target.value }))}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
                placeholder="https://example.com/avatar.jpg"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                URL обложки
              </label>
              <input
                type="url"
                value={profile.profile_banner_url}
                onChange={(e) => setProfile(prev => ({ ...prev, profile_banner_url: e.target.value }))}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-indigo-500"
                placeholder="https://example.com/banner.jpg"
              />
            </div>

            {/* Friend Code Display */}
            {profile.friend_code && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Ваш код друга
                </label>
                <div className="flex items-center space-x-2">
                  <code className="flex-1 px-3 py-2 bg-gray-900 border border-gray-600 rounded-lg text-white font-mono text-center text-lg">
                    {profile.friend_code}
                  </code>
                  <button
                    onClick={() => navigator.clipboard.writeText(profile.friend_code)}
                    className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors duration-200"
                    title="Скопировать код"
                  >
                    📋
                  </button>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  Поделитесь этим кодом с друзьями для быстрого добавления
                </p>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-3 mt-8">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-300 hover:text-white transition-colors duration-200"
            >
              Отмена
            </button>
            <button
              onClick={updateProfile}
              disabled={loading}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-600 text-white rounded-lg font-medium transition-colors duration-200 flex items-center space-x-2"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <Save className="w-4 h-4" />
              )}
              <span>Сохранить</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
