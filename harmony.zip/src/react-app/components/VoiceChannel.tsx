import { useState, useEffect, useRef, useCallback } from "react";
import { Mic, MicOff, Volume2, VolumeX, Phone, PhoneOff, Users, Monitor, MonitorOff } from "lucide-react";
import { useAuth } from "@getmocha/users-service/react";

interface VoiceChannelProps {
  channelId: number;
  channelName: string;
  onLeave: () => void;
}

interface VoiceUser {
  id: string;
  name: string;
  avatar: string | null;
  isMuted: boolean;
  isSpeaking: boolean;
  isScreenSharing: boolean;
}

export default function VoiceChannel({ channelId, channelName, onLeave }: VoiceChannelProps) {
  const { user } = useAuth();
  const [isConnected, setIsConnected] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isDeafened, setIsDeafened] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [voiceUsers, setVoiceUsers] = useState<VoiceUser[]>([]);
  const [localStream, setLocalStream] = useState<MediaStream | null>(null);
  const [screenStream, setScreenStream] = useState<MediaStream | null>(null);
  const [connecting, setConnecting] = useState(false);
  
  // Audio analysis for voice activity detection
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [dataArray, setDataArray] = useState<Uint8Array | null>(null);
  const [isSpeaking, setIsSpeaking] = useState(false);
  
  const remoteAudiosRef = useRef<Map<string, HTMLAudioElement>>(new Map());
  const animationFrameRef = useRef<number | null>(null);
  const participantsPollingRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (localStream) {
        localStream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      }
      if (screenStream) {
        screenStream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      }
      if (audioContext) {
        audioContext.close().catch(console.error);
      }
      if (animationFrameRef.current !== null) {
        cancelAnimationFrame(animationFrameRef.current);
      }
      if (isConnected) {
        leaveVoiceChannel();
      }
      setIsConnected(false);
    };
  }, [localStream, screenStream, audioContext]);

  // Voice activity detection
  const setupAudioAnalysis = useCallback((stream: MediaStream) => {
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioContextClass();
      const analyserNode = audioCtx.createAnalyser();
      const source = audioCtx.createMediaStreamSource(stream);
      
      analyserNode.fftSize = 256;
      const bufferLength = analyserNode.frequencyBinCount;
      const dataArr = new Uint8Array(bufferLength);
      
      source.connect(analyserNode);
      
      setAudioContext(audioCtx);
      setAnalyser(analyserNode);
      setDataArray(dataArr);
      
      return { audioCtx, analyserNode, dataArr };
    } catch (error) {
      console.error("Failed to setup audio analysis:", error);
      return null;
    }
  }, []);

  const detectVoiceActivity = useCallback(() => {
    if (!analyser || !dataArray || isMuted) {
      setIsSpeaking(false);
      // Update user speaking status
      setVoiceUsers(prev => prev.map(u => 
        u.id === user?.id ? { ...u, isSpeaking: false } : u
      ));
      animationFrameRef.current = requestAnimationFrame(detectVoiceActivity);
      return;
    }

    analyser.getByteFrequencyData(dataArray);
    
    // Calculate average volume
    const average = dataArray.reduce((acc, val) => acc + val, 0) / dataArray.length;
    const speaking = average > 30; // Threshold for speaking detection
    
    if (speaking !== isSpeaking) {
      setIsSpeaking(speaking);
      // Update user speaking status
      setVoiceUsers(prev => prev.map(u => 
        u.id === user?.id ? { ...u, isSpeaking: speaking } : u
      ));
    }

    animationFrameRef.current = requestAnimationFrame(detectVoiceActivity);
  }, [analyser, dataArray, isMuted, isSpeaking, user]);

  useEffect(() => {
    if (isConnected && analyser && dataArray) {
      animationFrameRef.current = requestAnimationFrame(detectVoiceActivity);
    }
    return () => {
      if (animationFrameRef.current !== null) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isConnected, analyser, dataArray, detectVoiceActivity]);

  const getUserMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }, 
        video: false 
      });
      setLocalStream(stream);
      
      // Setup audio analysis for voice activity detection
      setupAudioAnalysis(stream);
      
      return stream;
    } catch (error) {
      console.error("Failed to get user media:", error);
      alert("Не удалось получить доступ к микрофону");
      return null;
    }
  };

  const getScreenMedia = async () => {
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: true,
        audio: true
      });
      setScreenStream(stream);
      
      // Handle screen share ending
      stream.getVideoTracks()[0].addEventListener('ended', () => {
        stopScreenShare();
      });
      
      return stream;
    } catch (error) {
      console.error("Failed to get screen media:", error);
      alert("Не удалось получить доступ к экрану");
      return null;
    }
  };

  const connectToVoice = async () => {
    if (connecting || isConnected) return;
    
    setConnecting(true);
    try {
      const stream = await getUserMedia();
      if (stream) {
        // Join voice channel on server
        const response = await fetch(`/api/channels/${channelId}/voice/join`, {
          method: "POST",
        });
        
        if (response.ok) {
          setIsConnected(true);
          
          // Fetch current participants
          fetchVoiceParticipants();
          
          // Poll for participants updates
          startParticipantsPolling();
          
          console.log("Connected to voice channel:", channelId);
        } else {
          throw new Error("Failed to join voice channel");
        }
      }
    } catch (error) {
      console.error("Failed to connect to voice:", error);
      alert("Не удалось подключиться к голосовому каналу");
    } finally {
      setConnecting(false);
    }
  };

  const leaveVoiceChannel = async () => {
    try {
      await fetch(`/api/channels/${channelId}/voice/leave`, {
        method: "POST",
      });
    } catch (error) {
      console.error("Failed to leave voice channel:", error);
    }
  };

  const disconnectFromVoice = async () => {
    if (localStream) {
      localStream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      setLocalStream(null);
    }
    
    if (screenStream) {
      screenStream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      setScreenStream(null);
    }
    
    if (audioContext) {
      audioContext.close().catch(console.error);
      setAudioContext(null);
    }
    
    if (animationFrameRef.current !== null) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    
    stopParticipantsPolling();
    await leaveVoiceChannel();
    
    setVoiceUsers([]);
    setIsConnected(false);
    setIsScreenSharing(false);
    onLeave();
  };

  const toggleMute = () => {
    if (localStream) {
      const audioTrack = localStream.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
        
        // Update user's muted status in the list
        setVoiceUsers(prev => prev.map(u => 
          u.id === user?.id ? { ...u, isMuted: !audioTrack.enabled } : u
        ));
      }
    }
  };

  const toggleDeafen = () => {
    setIsDeafened(prev => {
      const newDeafened = !prev;
      
      // If deafening, also mute
      if (newDeafened && !isMuted) {
        toggleMute();
      }
      
      // Mute/unmute all remote audio elements
      remoteAudiosRef.current.forEach(audio => {
        audio.muted = newDeafened;
      });
      
      return newDeafened;
    });
  };

  const startScreenShare = async () => {
    if (isScreenSharing) return;
    
    const stream = await getScreenMedia();
    if (stream) {
      setIsScreenSharing(true);
      
      // Update user's screen sharing status
      setVoiceUsers(prev => prev.map(u => 
        u.id === user?.id ? { ...u, isScreenSharing: true } : u
      ));

      console.log("Started screen sharing");
    }
  };

  const stopScreenShare = () => {
    if (screenStream) {
      screenStream.getTracks().forEach((track: MediaStreamTrack) => track.stop());
      setScreenStream(null);
    }
    
    setIsScreenSharing(false);
    
    // Update user's screen sharing status
    setVoiceUsers(prev => prev.map(u => 
      u.id === user?.id ? { ...u, isScreenSharing: false } : u
    ));
    
    console.log("Stopped screen sharing");
  };

  const fetchVoiceParticipants = async () => {
    try {
      const response = await fetch(`/api/channels/${channelId}/voice/participants`);
      if (response.ok) {
        const participants = await response.json();
        setVoiceUsers(participants.map((p: any) => ({
          id: p.user_id,
          name: p.user_name || 'Unknown User',
          avatar: p.user_avatar,
          isMuted: p.is_muted,
          isSpeaking: false,
          isScreenSharing: p.is_screen_sharing,
        })));
      }
    } catch (error) {
      console.error("Failed to fetch voice participants:", error);
    }
  };

  const startParticipantsPolling = () => {
    participantsPollingRef.current = setInterval(() => {
      fetchVoiceParticipants();
    }, 2000); // Poll every 2 seconds
  };

  const stopParticipantsPolling = () => {
    if (participantsPollingRef.current) {
      clearInterval(participantsPollingRef.current);
      participantsPollingRef.current = null;
    }
  };

  const toggleScreenShare = () => {
    if (isScreenSharing) {
      stopScreenShare();
    } else {
      startScreenShare();
    }
  };

  if (!isConnected) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center max-w-md">
          <div className="w-24 h-24 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <Volume2 className="w-12 h-12 text-white" />
          </div>
          <h3 className="text-2xl font-bold text-white mb-4">#{channelName}</h3>
          <p className="text-gray-400 mb-8">
            Готовы присоединиться к голосовому каналу? Просто нажмите кнопку ниже.
          </p>
          
          <button
            onClick={connectToVoice}
            disabled={connecting}
            className="px-8 py-4 bg-green-600 hover:bg-green-700 disabled:bg-gray-600 text-white rounded-lg font-medium transition-colors duration-200 flex items-center space-x-2 mx-auto"
          >
            {connecting ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                <span>Подключение...</span>
              </>
            ) : (
              <>
                <Phone className="w-5 h-5" />
                <span>Подключиться</span>
              </>
            )}
          </button>
          
          <div className="mt-8 text-sm text-gray-500">
            <p>💡 Убедитесь, что браузер имеет доступ к микрофону</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Voice Header */}
      <div className="h-12 bg-gray-800 border-b border-gray-700 flex items-center justify-between px-4">
        <div className="flex items-center space-x-2">
          <Volume2 className="w-5 h-5 text-green-400" />
          <span className="text-white font-medium">#{channelName}</span>
          <div className="flex items-center space-x-1 text-sm text-green-400">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            <span>Подключен</span>
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <span className="text-gray-400 text-sm flex items-center space-x-1">
            <Users className="w-4 h-4" />
            <span>{voiceUsers.length}</span>
          </span>
        </div>
      </div>

      {/* Voice Users */}
      <div className="flex-1 p-6">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {voiceUsers.map((voiceUser) => (
            <div
              key={voiceUser.id}
              className={`relative bg-gray-800 rounded-xl p-4 border transition-all duration-200 ${
                voiceUser.isSpeaking 
                  ? 'border-green-400 shadow-lg shadow-green-400/20 ring-2 ring-green-400/30' 
                  : 'border-gray-700'
              }`}
            >
              <div className="text-center">
                <div className="relative mb-3">
                  {voiceUser.avatar ? (
                    <img
                      src={voiceUser.avatar}
                      alt={voiceUser.name}
                      className={`w-16 h-16 rounded-full mx-auto transition-all duration-200 ${
                        voiceUser.isSpeaking ? 'ring-2 ring-green-400' : ''
                      }`}
                    />
                  ) : (
                    <div className={`w-16 h-16 bg-indigo-600 rounded-full flex items-center justify-center mx-auto transition-all duration-200 ${
                      voiceUser.isSpeaking ? 'ring-2 ring-green-400' : ''
                    }`}>
                      <span className="text-lg font-semibold text-white">
                        {voiceUser.name.charAt(0).toUpperCase()}
                      </span>
                    </div>
                  )}
                  
                  {/* Muted Indicator */}
                  {voiceUser.isMuted && (
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-red-600 rounded-full flex items-center justify-center border-2 border-gray-800">
                      <MicOff className="w-3 h-3 text-white" />
                    </div>
                  )}
                  
                  {/* Screen Share Indicator */}
                  {voiceUser.isScreenSharing && (
                    <div className="absolute -top-1 -right-1 w-6 h-6 bg-blue-600 rounded-full flex items-center justify-center border-2 border-gray-800">
                      <Monitor className="w-3 h-3 text-white" />
                    </div>
                  )}
                  
                  {/* Speaking Animation */}
                  {voiceUser.isSpeaking && (
                    <div className="absolute inset-0 rounded-full bg-green-400/10 animate-pulse" />
                  )}
                </div>
                
                <p className="text-white font-medium text-sm truncate">
                  {voiceUser.name}
                  {voiceUser.id === user?.id && " (Вы)"}
                </p>
                
                {/* Voice Activity Indicator */}
                {voiceUser.isSpeaking && (
                  <div className="mt-1 flex justify-center">
                    <div className="flex space-x-1">
                      <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse"></div>
                      <div className="w-1 h-4 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-1 h-2 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-1 h-4 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.3s' }}></div>
                      <div className="w-1 h-3 bg-green-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Voice Controls */}
      <div className="h-20 bg-gray-900 border-t border-gray-700 flex items-center justify-center space-x-4 px-6">
        {/* Microphone Control */}
        <button
          onClick={toggleMute}
          className={`p-3 rounded-full transition-all duration-200 relative ${
            isMuted
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white'
          } ${isSpeaking && !isMuted ? 'ring-2 ring-green-400/50' : ''}`}
          title={isMuted ? 'Включить микрофон' : 'Выключить микрофон'}
        >
          {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          {isSpeaking && !isMuted && (
            <div className="absolute inset-0 rounded-full bg-green-400/20 animate-ping"></div>
          )}
        </button>

        {/* Audio Control */}
        <button
          onClick={toggleDeafen}
          className={`p-3 rounded-full transition-colors duration-200 ${
            isDeafened
              ? 'bg-red-600 hover:bg-red-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white'
          }`}
          title={isDeafened ? 'Включить звук' : 'Выключить звук'}
        >
          {isDeafened ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
        </button>

        {/* Screen Share Control */}
        <button
          onClick={toggleScreenShare}
          className={`p-3 rounded-full transition-colors duration-200 ${
            isScreenSharing
              ? 'bg-blue-600 hover:bg-blue-700 text-white'
              : 'bg-gray-700 hover:bg-gray-600 text-gray-300 hover:text-white'
          }`}
          title={isScreenSharing ? 'Остановить демонстрацию экрана' : 'Демонстрация экрана'}
        >
          {isScreenSharing ? <MonitorOff className="w-5 h-5" /> : <Monitor className="w-5 h-5" />}
        </button>

        <div className="w-px h-8 bg-gray-600" />

        {/* Disconnect */}
        <button
          onClick={disconnectFromVoice}
          className="p-3 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors duration-200"
          title="Отключиться от голосового канала"
        >
          <PhoneOff className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
