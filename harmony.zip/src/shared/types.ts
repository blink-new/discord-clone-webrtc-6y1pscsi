import z from "zod";

// Server schemas
export const ServerSchema = z.object({
  id: z.number(),
  name: z.string(),
  description: z.string().nullable(),
  icon_url: z.string().nullable(),
  owner_id: z.string(),
  invite_code: z.string().nullable(),
  is_public: z.boolean(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateServerSchema = z.object({
  name: z.string().min(1).max(100),
  description: z.string().optional(),
  is_public: z.boolean().default(true),
});

// Channel schemas
export const ChannelSchema = z.object({
  id: z.number(),
  server_id: z.number(),
  name: z.string(),
  type: z.enum(['text', 'voice']),
  description: z.string().nullable(),
  position: z.number(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateChannelSchema = z.object({
  name: z.string().min(1).max(100),
  type: z.enum(['text', 'voice']).default('text'),
  description: z.string().optional(),
});

// Message schemas
export const MessageSchema = z.object({
  id: z.number(),
  channel_id: z.number(),
  user_id: z.string(),
  content: z.string(),
  message_type: z.enum(['text', 'image', 'file']),
  reply_to_id: z.number().nullable(),
  edited_at: z.string().nullable(),
  created_at: z.string(),
  updated_at: z.string(),
});

export const CreateMessageSchema = z.object({
  content: z.string().min(1).max(2000),
  message_type: z.enum(['text', 'image', 'file']).default('text'),
  reply_to_id: z.number().optional(),
});

// Server member schemas
export const ServerMemberSchema = z.object({
  id: z.number(),
  server_id: z.number(),
  user_id: z.string(),
  nickname: z.string().nullable(),
  role: z.enum(['owner', 'admin', 'member']),
  permissions: z.string(),
  joined_at: z.string(),
  created_at: z.string(),
  updated_at: z.string(),
});

// User schemas
export const UserSchema = z.object({
  id: z.string(),
  email: z.string(),
  google_user_data: z.string(),
  display_name: z.string().nullable(),
  bio: z.string().nullable(),
  avatar_url: z.string().nullable(),
  status: z.enum(['online', 'idle', 'dnd', 'offline']),
  created_at: z.string(),
  updated_at: z.string(),
});

// Friendship schemas  
export const FriendshipSchema = z.object({
  id: z.number(),
  requester_id: z.string(),
  addressee_id: z.string(),
  status: z.enum(['pending', 'accepted', 'blocked']),
  created_at: z.string(),
  updated_at: z.string(),
});

// Member with user data
export const MemberWithUserSchema = z.object({
  id: z.number(),
  user_id: z.string(),
  user_name: z.string(),
  user_avatar: z.string().nullable(),
  role: z.enum(['owner', 'admin', 'member']),
  status: z.enum(['online', 'idle', 'dnd', 'offline']),
});

// Invite code schema
export const JoinByCodeSchema = z.object({
  invite_code: z.string().min(1).max(8),
});

// Types
export type Server = z.infer<typeof ServerSchema>;
export type CreateServer = z.infer<typeof CreateServerSchema>;
export type Channel = z.infer<typeof ChannelSchema>;
export type CreateChannel = z.infer<typeof CreateChannelSchema>;
export type Message = z.infer<typeof MessageSchema>;
export type CreateMessage = z.infer<typeof CreateMessageSchema>;
export type ServerMember = z.infer<typeof ServerMemberSchema>;
export type User = z.infer<typeof UserSchema>;
export type Friendship = z.infer<typeof FriendshipSchema>;
export type MemberWithUser = z.infer<typeof MemberWithUserSchema>;
export type JoinByCode = z.infer<typeof JoinByCodeSchema>;

// Extended types with user data
export type MessageWithUser = Message & {
  user_name: string;
  user_avatar: string | null;
};

export type ServerWithChannels = Server & {
  channels: Channel[];
  member_count: number;
};
