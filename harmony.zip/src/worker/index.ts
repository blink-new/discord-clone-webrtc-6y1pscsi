import { Hono } from "hono";
import { zValidator } from "@hono/zod-validator";
import { getCookie, setCookie } from "hono/cookie";
import {
  authMiddleware,
  getOAuthRedirectUrl,
  exchangeCodeForSessionToken,
  deleteSession,
  MOCHA_SESSION_TOKEN_COOKIE_NAME,
} from "@getmocha/users-service/backend";
import {
  CreateServerSchema,
  CreateChannelSchema,
  CreateMessageSchema,
  JoinByCodeSchema,
  type MessageWithUser,
  type MemberWithUser,
} from "@/shared/types";
import { z } from "zod";

const app = new Hono<{ Bindings: Env }>();

// Profile update schema
const UpdateProfileSchema = z.object({
  custom_nickname: z.string().optional(),
  custom_avatar_url: z.string().optional(),
  profile_banner_url: z.string().optional(),
  profile_color: z.string().optional(),
});

// Friend request schema
const SendFriendRequestSchema = z.object({
  receiver_email: z.string().email().optional(),
  friend_code: z.string().optional(),
}).refine(data => data.receiver_email || data.friend_code, {
  message: "Either email or friend code must be provided"
});

const RespondFriendRequestSchema = z.object({
  status: z.enum(['accepted', 'declined']),
});

// WebSocket connections management
const webSocketConnections = new Map<string, WebSocket>();
const voiceChannelParticipants = new Map<string, Set<string>>(); // channelId -> Set of userIds
const userWebSocketMap = new Map<string, string>(); // userId -> connectionId

function generateConnectionId(): string {
  return `conn_${Date.now()}_${Math.random().toString(36).substring(2)}`;
}

function notifyMessageSubscribers(channelId: string, message: any) {
  // Simple polling-based approach for now
  // In production, implement proper WebSocket or Server-Sent Events
  console.log(`New message in channel ${channelId}:`, message);
}

function broadcastToVoiceChannel(channelId: string, data: any, excludeUserId?: string) {
  const participants = voiceChannelParticipants.get(channelId);
  if (!participants) return;

  participants.forEach(userId => {
    if (excludeUserId && userId === excludeUserId) return;
    
    const connectionId = userWebSocketMap.get(userId);
    if (connectionId) {
      const ws = webSocketConnections.get(connectionId);
      if (ws && ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(JSON.stringify(data));
        } catch (error) {
          console.error('Failed to send WebSocket message:', error);
        }
      }
    }
  });
}

// Auth endpoints
app.get('/api/oauth/google/redirect_url', async (c) => {
  try {
    const redirectUrl = await getOAuthRedirectUrl('google', {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    return c.json({ redirectUrl }, 200);
  } catch (error) {
    console.error("OAuth redirect error:", error);
    return c.json({ error: "Failed to get OAuth URL" }, 500);
  }
});

app.post("/api/sessions", async (c) => {
  try {
    const body = await c.req.json();

    if (!body.code) {
      return c.json({ error: "No authorization code provided" }, 400);
    }

    const sessionToken = await exchangeCodeForSessionToken(body.code, {
      apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
      apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
    });

    setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, sessionToken, {
      httpOnly: true,
      path: "/",
      sameSite: "none",
      secure: true,
      maxAge: 60 * 24 * 60 * 60, // 60 days
    });

    return c.json({ success: true }, 200);
  } catch (error) {
    console.error("Session creation error:", error);
    return c.json({ error: "Failed to create session" }, 400);
  }
});

app.get("/api/users/me", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  // Ensure user exists and has friend code
  let dbUser = await c.env.DB.prepare(`
    SELECT * FROM users WHERE id = ?
  `).bind(user.id).first();

  if (!dbUser) {
    // Generate unique friend code
    let friendCode = '';
    let isUnique = false;
    while (!isUnique) {
      friendCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const existing = await c.env.DB.prepare(`
        SELECT 1 FROM users WHERE friend_code = ?
      `).bind(friendCode).first();
      if (!existing) isUnique = true;
    }

    await c.env.DB.prepare(`
      INSERT INTO users (id, email, google_user_data, friend_code)
      VALUES (?, ?, ?, ?)
    `).bind(user.id, user.email, JSON.stringify(user.google_user_data), friendCode).run();

    dbUser = await c.env.DB.prepare(`
      SELECT * FROM users WHERE id = ?
    `).bind(user.id).first();
  } else if (!dbUser.friend_code) {
    // Generate friend code for existing user
    let friendCode = '';
    let isUnique = false;
    while (!isUnique) {
      friendCode = Math.random().toString(36).substring(2, 8).toUpperCase();
      const existing = await c.env.DB.prepare(`
        SELECT 1 FROM users WHERE friend_code = ?
      `).bind(friendCode).first();
      if (!existing) isUnique = true;
    }

    await c.env.DB.prepare(`
      UPDATE users SET friend_code = ? WHERE id = ?
    `).bind(friendCode, user.id).run();

    dbUser = await c.env.DB.prepare(`
      SELECT * FROM users WHERE id = ?
    `).bind(user.id).first();
  }

  return c.json({
    ...user,
    custom_nickname: dbUser?.custom_nickname,
    custom_avatar_url: dbUser?.custom_avatar_url,
    profile_banner_url: dbUser?.profile_banner_url,
    profile_color: dbUser?.profile_color || '#5865F2',
    friend_code: dbUser?.friend_code,
  });
});

app.patch("/api/users/me", authMiddleware, zValidator("json", UpdateProfileSchema), async (c) => {
  const user = c.get("user")!;
  const data = c.req.valid("json");

  // Upsert user record
  await c.env.DB.prepare(`
    INSERT INTO users (
      id, email, google_user_data, custom_nickname, custom_avatar_url, profile_banner_url, profile_color
    ) VALUES (?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      custom_nickname = excluded.custom_nickname,
      custom_avatar_url = excluded.custom_avatar_url,
      profile_banner_url = excluded.profile_banner_url,
      profile_color = excluded.profile_color,
      updated_at = CURRENT_TIMESTAMP
  `).bind(
    user.id,
    user.email,
    JSON.stringify(user.google_user_data),
    data.custom_nickname || null,
    data.custom_avatar_url || null,
    data.profile_banner_url || null,
    data.profile_color || '#5865F2'
  ).run();

  return c.json({ success: true });
});

app.get('/api/logout', async (c) => {
  const sessionToken = getCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME);

  if (typeof sessionToken === 'string') {
    try {
      await deleteSession(sessionToken, {
        apiUrl: c.env.MOCHA_USERS_SERVICE_API_URL,
        apiKey: c.env.MOCHA_USERS_SERVICE_API_KEY,
      });
    } catch (error) {
      console.error("Session deletion error:", error);
    }
  }

  setCookie(c, MOCHA_SESSION_TOKEN_COOKIE_NAME, '', {
    httpOnly: true,
    path: '/',
    sameSite: 'none',
    secure: true,
    maxAge: 0,
  });

  return c.json({ success: true }, 200);
});

// Friend system endpoints
app.get("/api/friends", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(`
    SELECT 
      fr.*,
      CASE 
        WHEN fr.sender_id = ? THEN u2.email
        ELSE u1.email
      END as friend_email,
      CASE 
        WHEN fr.sender_id = ? THEN u2.google_user_data
        ELSE u1.google_user_data
      END as friend_data,
      CASE 
        WHEN fr.sender_id = ? THEN u2.custom_nickname
        ELSE u1.custom_nickname
      END as custom_nickname,
      CASE 
        WHEN fr.sender_id = ? THEN u2.custom_avatar_url
        ELSE u1.custom_avatar_url
      END as custom_avatar_url
    FROM friend_requests fr
    JOIN users u1 ON fr.sender_id = u1.id
    JOIN users u2 ON fr.receiver_id = u2.id
    WHERE (fr.sender_id = ? OR fr.receiver_id = ?) AND fr.status = 'accepted'
  `).bind(user.id, user.id, user.id, user.id, user.id, user.id).all();

  return c.json(results);
});

app.get("/api/friend-requests", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  const { results } = await c.env.DB.prepare(`
    SELECT 
      fr.*,
      u.email as sender_email,
      u.google_user_data as sender_data,
      u.custom_nickname,
      u.custom_avatar_url
    FROM friend_requests fr
    JOIN users u ON fr.sender_id = u.id
    WHERE fr.receiver_id = ? AND fr.status = 'pending'
  `).bind(user.id).all();

  return c.json(results);
});

app.post("/api/friend-requests", authMiddleware, zValidator("json", SendFriendRequestSchema), async (c) => {
  const user = c.get("user")!;
  const { receiver_email, friend_code } = c.req.valid("json");

  let receiver;
  
  if (friend_code) {
    // Find receiver by friend code
    receiver = await c.env.DB.prepare(`
      SELECT id, email FROM users WHERE friend_code = ?
    `).bind(friend_code.toUpperCase()).first();
    
    if (!receiver) {
      return c.json({ error: "Friend code not found" }, 404);
    }
  } else if (receiver_email) {
    // Find receiver by email
    receiver = await c.env.DB.prepare(`
      SELECT id, email FROM users WHERE email = ?
    `).bind(receiver_email).first();
    
    if (!receiver) {
      return c.json({ error: "User not found" }, 404);
    }
  } else {
    return c.json({ error: "Either email or friend code must be provided" }, 400);
  }

  if (receiver.id === user.id) {
    return c.json({ error: "Cannot send friend request to yourself" }, 400);
  }

  // Check if request already exists
  const existing = await c.env.DB.prepare(`
    SELECT 1 FROM friend_requests 
    WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
  `).bind(user.id, receiver.id, receiver.id, user.id).first();

  if (existing) {
    return c.json({ error: "Friend request already exists" }, 400);
  }

  await c.env.DB.prepare(`
    INSERT INTO friend_requests (sender_id, receiver_id)
    VALUES (?, ?)
  `).bind(user.id, receiver.id).run();

  return c.json({ success: true });
});

app.patch("/api/friend-requests/:id", authMiddleware, zValidator("json", RespondFriendRequestSchema), async (c) => {
  const user = c.get("user")!;
  const requestId = c.req.param("id");
  const { status } = c.req.valid("json");

  const request = await c.env.DB.prepare(`
    SELECT * FROM friend_requests WHERE id = ? AND receiver_id = ?
  `).bind(requestId, user.id).first();

  if (!request) {
    return c.json({ error: "Friend request not found" }, 404);
  }

  await c.env.DB.prepare(`
    UPDATE friend_requests SET status = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).bind(status, requestId).run();

  return c.json({ success: true });
});

// Discovery endpoints
app.get("/api/discovery/servers", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  try {
    // Ensure user exists in database
    await c.env.DB.prepare(`
      INSERT OR IGNORE INTO users (id, email, google_user_data)
      VALUES (?, ?, ?)
    `).bind(user.id, user.email, JSON.stringify(user.google_user_data)).run();

    const { results } = await c.env.DB.prepare(`
      SELECT s.*, COUNT(sm.id) as member_count
      FROM servers s
      LEFT JOIN server_members sm ON s.id = sm.server_id
      WHERE s.is_public = 1
      AND s.id NOT IN (
        SELECT server_id FROM server_members WHERE user_id = ?
      )
      GROUP BY s.id
      ORDER BY member_count DESC, s.created_at DESC
      LIMIT 50
    `).bind(user.id).all();

    return c.json(results);
  } catch (error) {
    console.error("Discovery servers error:", error);
    return c.json({ error: "Failed to fetch servers" }, 500);
  }
});

app.post("/api/servers/join-by-code", authMiddleware, zValidator("json", JoinByCodeSchema), async (c) => {
  const user = c.get("user")!;
  const { invite_code } = c.req.valid("json");
  
  const server = await c.env.DB.prepare(`
    SELECT * FROM servers WHERE invite_code = ?
  `).bind(invite_code).first();

  if (!server) {
    return c.json({ error: "Invalid invite code" }, 404);
  }

  // Check if already a member
  const existing = await c.env.DB.prepare(`
    SELECT 1 FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(server.id, user.id).first();

  if (existing) {
    return c.json(server);
  }

  // Add as member
  await c.env.DB.prepare(`
    INSERT INTO server_members (server_id, user_id, role)
    VALUES (?, ?, 'member')
  `).bind(server.id, user.id).run();

  return c.json(server);
});

app.post("/api/servers/:id/join", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const serverId = c.req.param("id");

  const server = await c.env.DB.prepare(`
    SELECT * FROM servers WHERE id = ? AND is_public = 1
  `).bind(serverId).first();

  if (!server) {
    return c.json({ error: "Server not found or not public" }, 404);
  }

  // Check if already a member
  const existing = await c.env.DB.prepare(`
    SELECT 1 FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(serverId, user.id).first();

  if (existing) {
    return c.json({ success: true });
  }

  // Add as member
  await c.env.DB.prepare(`
    INSERT INTO server_members (server_id, user_id, role)
    VALUES (?, ?, 'member')
  `).bind(serverId, user.id).run();

  return c.json({ success: true });
});

// Server endpoints
app.get("/api/servers", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  // Ensure user exists in database
  await c.env.DB.prepare(`
    INSERT OR IGNORE INTO users (id, email, google_user_data)
    VALUES (?, ?, ?)
  `).bind(user.id, user.email, JSON.stringify(user.google_user_data)).run();
  
  const { results } = await c.env.DB.prepare(`
    SELECT s.*, COUNT(sm.id) as member_count
    FROM servers s
    JOIN server_members sm ON s.id = sm.server_id
    WHERE s.id IN (
      SELECT server_id FROM server_members WHERE user_id = ?
    )
    GROUP BY s.id
    ORDER BY s.created_at DESC
  `).bind(user.id).all();

  return c.json(results);
});

app.post("/api/servers", authMiddleware, zValidator("json", CreateServerSchema), async (c) => {
  const user = c.get("user")!;
  const data = c.req.valid("json");
  
  const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  
  const serverResult = await c.env.DB.prepare(`
    INSERT INTO servers (name, description, owner_id, invite_code, is_public)
    VALUES (?, ?, ?, ?, ?)
  `).bind(data.name, data.description || null, user.id, inviteCode, data.is_public).run();

  const serverId = serverResult.meta.last_row_id;

  // Add owner as member
  await c.env.DB.prepare(`
    INSERT INTO server_members (server_id, user_id, role)
    VALUES (?, ?, 'owner')
  `).bind(serverId, user.id).run();

  // Create default channels
  await c.env.DB.prepare(`
    INSERT INTO channels (server_id, name, type, position)
    VALUES (?, 'general', 'text', 0), (?, 'General', 'voice', 1)
  `).bind(serverId, serverId).run();

  const server = await c.env.DB.prepare(`
    SELECT * FROM servers WHERE id = ?
  `).bind(serverId).first();

  return c.json(server, 201);
});

app.get("/api/servers/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const serverId = c.req.param("id");

  // Check if user is member
  const membership = await c.env.DB.prepare(`
    SELECT 1 FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(serverId, user.id).first();

  if (!membership) {
    return c.json({ error: "Not a member of this server" }, 403);
  }

  const server = await c.env.DB.prepare(`
    SELECT * FROM servers WHERE id = ?
  `).bind(serverId).first();

  const channels = await c.env.DB.prepare(`
    SELECT * FROM channels WHERE server_id = ? ORDER BY position ASC
  `).bind(serverId).all();

  return c.json({ ...server, channels: channels.results });
});

app.patch("/api/servers/:id", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const serverId = c.req.param("id");
  
  // Check if user is owner
  const membership = await c.env.DB.prepare(`
    SELECT role FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(serverId, user.id).first();

  if (!membership || membership.role !== 'owner') {
    return c.json({ error: "Only server owners can update server settings" }, 403);
  }

  const body = await c.req.json();
  
  if (body.name) {
    await c.env.DB.prepare(`
      UPDATE servers SET name = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
    `).bind(body.name, serverId).run();
  }

  return c.json({ success: true });
});

app.post("/api/servers/:id/invite-code", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const serverId = c.req.param("id");
  
  // Check if user is owner
  const membership = await c.env.DB.prepare(`
    SELECT role FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(serverId, user.id).first();

  if (!membership || membership.role !== 'owner') {
    return c.json({ error: "Only server owners can generate invite codes" }, 403);
  }

  const inviteCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  
  await c.env.DB.prepare(`
    UPDATE servers SET invite_code = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?
  `).bind(inviteCode, serverId).run();

  return c.json({ invite_code: inviteCode });
});

app.get("/api/servers/:id/members", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const serverId = c.req.param("id");

  // Check if user is member
  const membership = await c.env.DB.prepare(`
    SELECT 1 FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(serverId, user.id).first();

  if (!membership) {
    return c.json({ error: "Not a member of this server" }, 403);
  }

  const { results } = await c.env.DB.prepare(`
    SELECT 
      sm.id,
      sm.user_id,
      sm.role,
      COALESCE(
        u.custom_nickname, 
        JSON_EXTRACT(u.google_user_data, '$.name'),
        JSON_EXTRACT(u.google_user_data, '$.given_name'),
        u.email, 
        'User ' || substr(sm.user_id, 1, 8)
      ) as user_name,
      COALESCE(
        u.custom_avatar_url,
        JSON_EXTRACT(u.google_user_data, '$.picture')
      ) as user_avatar,
      'online' as status
    FROM server_members sm
    LEFT JOIN users u ON sm.user_id = u.id
    WHERE sm.server_id = ?
    ORDER BY 
      CASE sm.role 
        WHEN 'owner' THEN 1 
        WHEN 'admin' THEN 2 
        ELSE 3 
      END,
      user_name ASC
  `).bind(serverId).all();

  const members: MemberWithUser[] = results.map((row: any) => ({
    id: row.id,
    user_id: row.user_id,
    user_name: row.user_name || `User ${row.user_id}`,
    user_avatar: row.user_avatar,
    role: row.role,
    status: row.status,
  }));

  return c.json(members);
});

// WebSocket endpoint for voice chat signaling
app.get("/api/voice/ws", async (c) => {
  const upgradeHeader = c.req.header("Upgrade");
  if (upgradeHeader !== "websocket") {
    return c.text("Expected Upgrade: websocket", 426);
  }

  const webSocketPair = new WebSocketPair();
  const [client, server] = Object.values(webSocketPair);

  server.accept();
  
  const connectionId = generateConnectionId();
  webSocketConnections.set(connectionId, server);

  let userId: string | null = null;
  let channelId: string | null = null;

  server.addEventListener("message", async (event) => {
    try {
      const data = JSON.parse(event.data as string);
      
      switch (data.type) {
        case 'join-channel':
          userId = data.userId;
          channelId = data.channelId;
          
          if (userId && channelId) {
            // Add user to channel participants
            if (!voiceChannelParticipants.has(channelId)) {
              voiceChannelParticipants.set(channelId, new Set());
            }
            voiceChannelParticipants.get(channelId)!.add(userId);
            userWebSocketMap.set(userId, connectionId);

            // Notify other participants about new user
            broadcastToVoiceChannel(channelId, {
              type: 'user-joined',
              userId: userId,
              channelId: channelId
            }, userId);

            // Send current participants to new user
            const participants = Array.from(voiceChannelParticipants.get(channelId) || []);
            server.send(JSON.stringify({
              type: 'participants-list',
              participants: participants.filter(id => id !== userId)
            }));
          }
          break;

        case 'offer':
          if (channelId && userId) {
            const targetConnectionId = userWebSocketMap.get(data.targetUserId);
            if (targetConnectionId) {
              const targetWs = webSocketConnections.get(targetConnectionId);
              if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                targetWs.send(JSON.stringify({
                  type: 'offer',
                  offer: data.offer,
                  fromUserId: userId
                }));
              }
            }
          }
          break;

        case 'answer':
          if (channelId && userId) {
            const targetConnectionId = userWebSocketMap.get(data.targetUserId);
            if (targetConnectionId) {
              const targetWs = webSocketConnections.get(targetConnectionId);
              if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                targetWs.send(JSON.stringify({
                  type: 'answer',
                  answer: data.answer,
                  fromUserId: userId
                }));
              }
            }
          }
          break;

        case 'ice-candidate':
          if (channelId && userId) {
            const targetConnectionId = userWebSocketMap.get(data.targetUserId);
            if (targetConnectionId) {
              const targetWs = webSocketConnections.get(targetConnectionId);
              if (targetWs && targetWs.readyState === WebSocket.OPEN) {
                targetWs.send(JSON.stringify({
                  type: 'ice-candidate',
                  candidate: data.candidate,
                  fromUserId: userId
                }));
              }
            }
          }
          break;

        case 'speaking':
          if (channelId && userId) {
            broadcastToVoiceChannel(channelId, {
              type: 'speaking',
              userId: userId,
              speaking: data.speaking
            }, userId);
          }
          break;

        case 'mute-status':
          if (channelId && userId) {
            broadcastToVoiceChannel(channelId, {
              type: 'mute-status',
              userId: userId,
              muted: data.muted
            }, userId);
          }
          break;
      }
    } catch (error) {
      console.error('WebSocket message error:', error);
    }
  });

  server.addEventListener("close", () => {
    // Clean up on disconnect
    if (userId && channelId) {
      const participants = voiceChannelParticipants.get(channelId);
      if (participants) {
        participants.delete(userId);
        if (participants.size === 0) {
          voiceChannelParticipants.delete(channelId);
        }
      }
      userWebSocketMap.delete(userId);

      // Notify other participants about user leaving
      broadcastToVoiceChannel(channelId, {
        type: 'user-left',
        userId: userId
      });
    }
    
    webSocketConnections.delete(connectionId);
  });

  return new Response(null, {
    status: 101,
    webSocket: client,
  });
});

// Voice channel endpoints
app.post("/api/channels/:id/voice/join", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const channelId = c.req.param("id");

  // Check access
  const channel = await c.env.DB.prepare(`
    SELECT c.* FROM channels c
    JOIN server_members sm ON c.server_id = sm.server_id
    WHERE c.id = ? AND c.type = 'voice' AND sm.user_id = ?
  `).bind(channelId, user.id).first();

  if (!channel) {
    return c.json({ error: "Channel not found or no access" }, 404);
  }

  // Add to voice participants
  await c.env.DB.prepare(`
    INSERT OR REPLACE INTO voice_participants (channel_id, user_id)
    VALUES (?, ?)
  `).bind(channelId, user.id).run();

  return c.json({ success: true });
});

app.post("/api/channels/:id/voice/leave", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const channelId = c.req.param("id");

  await c.env.DB.prepare(`
    DELETE FROM voice_participants WHERE channel_id = ? AND user_id = ?
  `).bind(channelId, user.id).run();

  return c.json({ success: true });
});

app.get("/api/channels/:id/voice/participants", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const channelId = c.req.param("id");

  // Check access
  const channel = await c.env.DB.prepare(`
    SELECT c.* FROM channels c
    JOIN server_members sm ON c.server_id = sm.server_id
    WHERE c.id = ? AND c.type = 'voice' AND sm.user_id = ?
  `).bind(channelId, user.id).first();

  if (!channel) {
    return c.json({ error: "Channel not found or no access" }, 404);
  }

  const { results } = await c.env.DB.prepare(`
    SELECT 
      vp.*,
      COALESCE(
        u.custom_nickname, 
        JSON_EXTRACT(u.google_user_data, '$.name'),
        JSON_EXTRACT(u.google_user_data, '$.given_name'),
        u.email, 
        'User ' || substr(vp.user_id, 1, 8)
      ) as user_name,
      COALESCE(
        u.custom_avatar_url,
        JSON_EXTRACT(u.google_user_data, '$.picture')
      ) as user_avatar
    FROM voice_participants vp
    LEFT JOIN users u ON vp.user_id = u.id
    WHERE vp.channel_id = ?
  `).bind(channelId).all();

  return c.json(results);
});

// Channel endpoints
app.post("/api/servers/:serverId/channels", authMiddleware, zValidator("json", CreateChannelSchema), async (c) => {
  const user = c.get("user")!;
  const serverId = c.req.param("serverId");
  const data = c.req.valid("json");

  // Check if user is admin/owner
  const membership = await c.env.DB.prepare(`
    SELECT role FROM server_members WHERE server_id = ? AND user_id = ?
  `).bind(serverId, user.id).first();

  if (!membership || !['owner', 'admin'].includes(membership.role as string)) {
    return c.json({ error: "Insufficient permissions" }, 403);
  }

  const result = await c.env.DB.prepare(`
    INSERT INTO channels (server_id, name, type, description)
    VALUES (?, ?, ?, ?)
  `).bind(serverId, data.name, data.type, data.description || null).run();

  const channel = await c.env.DB.prepare(`
    SELECT * FROM channels WHERE id = ?
  `).bind(result.meta.last_row_id).first();

  return c.json(channel, 201);
});

// Message endpoints
app.get("/api/channels/:id/messages", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const channelId = c.req.param("id");
  const limit = Math.min(parseInt(c.req.query("limit") || "50"), 100);
  const before = c.req.query("before");

  // Check if user has access to this channel
  const channel = await c.env.DB.prepare(`
    SELECT c.*, sm.user_id FROM channels c
    JOIN server_members sm ON c.server_id = sm.server_id
    WHERE c.id = ? AND sm.user_id = ?
  `).bind(channelId, user.id).first();

  if (!channel) {
    return c.json({ error: "Channel not found or no access" }, 404);
  }

  let query = `
    SELECT 
      m.*,
      COALESCE(
        u.custom_nickname, 
        JSON_EXTRACT(u.google_user_data, '$.name'),
        JSON_EXTRACT(u.google_user_data, '$.given_name'),
        u.email, 
        'User ' || substr(m.user_id, 1, 8)
      ) as user_name,
      COALESCE(
        u.custom_avatar_url,
        JSON_EXTRACT(u.google_user_data, '$.picture')
      ) as user_avatar
    FROM messages m
    LEFT JOIN users u ON m.user_id = u.id
    WHERE m.channel_id = ?
  `;
  const params = [channelId];

  if (before) {
    query += ` AND m.id < ?`;
    params.push(before);
  }

  query += ` ORDER BY m.created_at DESC LIMIT ?`;
  params.push(limit.toString());

  const { results } = await c.env.DB.prepare(query).bind(...params).all();

  // Transform results to include user info
  const messages: MessageWithUser[] = results.map((row: any) => ({
    id: row.id,
    channel_id: row.channel_id,
    user_id: row.user_id,
    content: row.content,
    message_type: row.message_type,
    reply_to_id: row.reply_to_id,
    edited_at: row.edited_at,
    created_at: row.created_at,
    updated_at: row.updated_at,
    user_name: row.user_name || 'Unknown User',
    user_avatar: row.user_avatar,
  }));

  return c.json(messages.reverse());
});

app.post("/api/channels/:id/messages", authMiddleware, zValidator("json", CreateMessageSchema), async (c) => {
  const user = c.get("user")!;
  const channelId = c.req.param("id");
  const data = c.req.valid("json");

  // Check if user has access to this channel
  const channel = await c.env.DB.prepare(`
    SELECT c.* FROM channels c
    JOIN server_members sm ON c.server_id = sm.server_id
    WHERE c.id = ? AND sm.user_id = ?
  `).bind(channelId, user.id).first();

  if (!channel) {
    return c.json({ error: "Channel not found or no access" }, 404);
  }

  // Ensure user exists in database
  await c.env.DB.prepare(`
    INSERT OR IGNORE INTO users (id, email, google_user_data)
    VALUES (?, ?, ?)
  `).bind(user.id, user.email, JSON.stringify(user.google_user_data)).run();

  const result = await c.env.DB.prepare(`
    INSERT INTO messages (channel_id, user_id, content, message_type, reply_to_id)
    VALUES (?, ?, ?, ?, ?)
  `).bind(channelId, user.id, data.content, data.message_type, data.reply_to_id || null).run();

  const message = await c.env.DB.prepare(`
    SELECT 
      m.*,
      COALESCE(
        u.custom_nickname, 
        JSON_EXTRACT(u.google_user_data, '$.name'),
        JSON_EXTRACT(u.google_user_data, '$.given_name'),
        u.email, 
        'User ' || substr(m.user_id, 1, 8)
      ) as user_name,
      COALESCE(
        u.custom_avatar_url,
        JSON_EXTRACT(u.google_user_data, '$.picture')
      ) as user_avatar
    FROM messages m
    LEFT JOIN users u ON m.user_id = u.id
    WHERE m.id = ?
  `).bind(result.meta.last_row_id).first();

  // Notify subscribers (simplified approach)
  notifyMessageSubscribers(channelId, message);

  return c.json(message, 201);
});

// Direct messages endpoints
app.get("/api/direct-messages/:friendId", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const friendId = c.req.param("friendId");

  // Check if they are friends
  const friendship = await c.env.DB.prepare(`
    SELECT 1 FROM friend_requests 
    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
    AND status = 'accepted'
  `).bind(user.id, friendId, friendId, user.id).first();

  if (!friendship) {
    return c.json({ error: "Not friends with this user" }, 403);
  }

  const { results } = await c.env.DB.prepare(`
    SELECT 
      dm.*,
      COALESCE(
        u.custom_nickname, 
        JSON_EXTRACT(u.google_user_data, '$.name'),
        JSON_EXTRACT(u.google_user_data, '$.given_name'),
        u.email, 
        'User ' || substr(dm.sender_id, 1, 8)
      ) as sender_name,
      COALESCE(
        u.custom_avatar_url,
        JSON_EXTRACT(u.google_user_data, '$.picture')
      ) as sender_avatar
    FROM direct_messages dm
    LEFT JOIN users u ON dm.sender_id = u.id
    WHERE (dm.sender_id = ? AND dm.recipient_id = ?) 
       OR (dm.sender_id = ? AND dm.recipient_id = ?)
    ORDER BY dm.created_at ASC
    LIMIT 100
  `).bind(user.id, friendId, friendId, user.id).all();

  return c.json(results);
});

app.post("/api/direct-messages", authMiddleware, async (c) => {
  const user = c.get("user")!;
  const body = await c.req.json();
  const { recipient_id, content } = body;

  if (!recipient_id || !content?.trim()) {
    return c.json({ error: "Missing recipient_id or content" }, 400);
  }

  // Check if they are friends
  const friendship = await c.env.DB.prepare(`
    SELECT 1 FROM friend_requests 
    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
    AND status = 'accepted'
  `).bind(user.id, recipient_id, recipient_id, user.id).first();

  if (!friendship) {
    return c.json({ error: "Not friends with this user" }, 403);
  }

  // Ensure users exist in database
  await c.env.DB.prepare(`
    INSERT OR IGNORE INTO users (id, email, google_user_data)
    VALUES (?, ?, ?)
  `).bind(user.id, user.email, JSON.stringify(user.google_user_data)).run();

  const result = await c.env.DB.prepare(`
    INSERT INTO direct_messages (sender_id, recipient_id, content)
    VALUES (?, ?, ?)
  `).bind(user.id, recipient_id, content.trim()).run();

  const message = await c.env.DB.prepare(`
    SELECT 
      dm.*,
      COALESCE(
        u.custom_nickname, 
        JSON_EXTRACT(u.google_user_data, '$.name'),
        JSON_EXTRACT(u.google_user_data, '$.given_name'),
        u.email, 
        'User ' || substr(dm.sender_id, 1, 8)
      ) as sender_name,
      COALESCE(
        u.custom_avatar_url,
        JSON_EXTRACT(u.google_user_data, '$.picture')
      ) as sender_avatar
    FROM direct_messages dm
    LEFT JOIN users u ON dm.sender_id = u.id
    WHERE dm.id = ?
  `).bind(result.meta.last_row_id).first();

  return c.json(message, 201);
});

// File upload endpoint
app.post("/api/upload", authMiddleware, async (c) => {
  const user = c.get("user")!;
  
  try {
    const formData = await c.req.formData();
    const file = formData.get('file') as File;
    
    if (!file) {
      return c.json({ error: "No file provided" }, 400);
    }

    // Simple file validation
    const maxSize = 10 * 1024 * 1024; // 10MB
    if (file.size > maxSize) {
      return c.json({ error: "File too large" }, 400);
    }

    // Generate unique filename
    const fileId = crypto.randomUUID();
    const extension = file.name.split('.').pop() || '';
    const filename = `${fileId}.${extension}`;
    
    // In a real implementation, you would upload to cloud storage
    // For now, just return a mock URL
    const mockUrl = `https://cdn.example.com/uploads/${filename}`;

    // Save file record to database
    await c.env.DB.prepare(`
      INSERT INTO file_uploads (user_id, filename, original_name, mime_type, size, url)
      VALUES (?, ?, ?, ?, ?, ?)
    `).bind(user.id, filename, file.name, file.type, file.size, mockUrl).run();

    return c.json({
      id: fileId,
      filename,
      original_name: file.name,
      url: mockUrl,
      size: file.size,
      mime_type: file.type,
    });
  } catch (error) {
    console.error("File upload error:", error);
    return c.json({ error: "Upload failed" }, 500);
  }
});

export default app;
