
DROP TABLE messages;
DROP TABLE server_members;
DROP TABLE channels;
DROP TABLE servers;
