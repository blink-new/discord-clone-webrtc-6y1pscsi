
ALTER TABLE users ADD COLUMN friend_code TEXT;
CREATE UNIQUE INDEX idx_users_friend_code ON users(friend_code) WHERE friend_code IS NOT NULL;
