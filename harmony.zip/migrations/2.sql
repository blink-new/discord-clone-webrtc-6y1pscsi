
-- Add is_public column to servers table
ALTER TABLE servers ADD COLUMN is_public BOOLEAN DEFAULT true;

-- Add permissions column to server_members table for role-based permissions
ALTER TABLE server_members ADD COLUMN permissions TEXT DEFAULT '{}';

-- Create a users table to store user profiles for friend system
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  google_user_data TEXT NOT NULL,
  display_name TEXT,
  bio TEXT,
  avatar_url TEXT,
  status TEXT DEFAULT 'online',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create friendships table
CREATE TABLE friendships (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  requester_id TEXT NOT NULL,
  addressee_id TEXT NOT NULL,
  status TEXT DEFAULT 'pending', -- 'pending', 'accepted', 'blocked'
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create direct_messages table for DMs
CREATE TABLE direct_messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  sender_id TEXT NOT NULL,
  recipient_id TEXT NOT NULL,
  content TEXT NOT NULL,
  message_type TEXT DEFAULT 'text',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
