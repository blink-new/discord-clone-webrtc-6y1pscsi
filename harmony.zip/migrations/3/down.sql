
-- Remove profile customization fields
ALTER TABLE users DROP COLUMN custom_nickname;
ALTER TABLE users DROP COLUMN custom_avatar_url;
ALTER TABLE users DROP COLUMN profile_banner_url;
ALTER TABLE users DROP COLUMN profile_color;

-- Remove friendship system
DROP TABLE IF EXISTS friend_requests;

-- Remove file uploads
DROP TABLE IF EXISTS file_uploads;

-- Remove voice participants
DROP TABLE IF EXISTS voice_participants;
