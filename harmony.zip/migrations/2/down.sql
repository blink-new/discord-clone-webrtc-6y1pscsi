
-- Remove added columns
ALTER TABLE servers DROP COLUMN is_public;
ALTER TABLE server_members DROP COLUMN permissions;

-- Drop new tables
DROP TABLE users;
DROP TABLE friendships;
DROP TABLE direct_messages;
