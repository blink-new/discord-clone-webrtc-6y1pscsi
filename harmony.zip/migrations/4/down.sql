
DROP INDEX IF EXISTS idx_users_friend_code;
ALTER TABLE users DROP COLUMN friend_code;
